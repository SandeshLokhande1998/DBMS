/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.mongodb.*;
import java.util.*;
/**
 *
 * @author 
 */
public class MongoConn 
{

    public static void main(String[] args) 
    {
         int ch;
         Scanner sc=new Scanner(System.in);
         DB db;
         String name;
         DBCollection collectionName;
         DBCursor cursor;
         BasicDBObject doc;
        // TODO code application logic here
        try
        {
                Mongo mongoClient = new Mongo( "localhost" , 27017 );      
                db = mongoClient.getDB( "mydb" );
                System.out.print("Enter the collection name:- ");
                name=sc.next();
              System.out.println("Connect to database successfully");
            do
            {
                System.out.println("\n\n-----CRUD OPERATIONS-----");
                System.out.println("1.Create the collction");
                         
                System.out.println("2.Insert the document");
                System.out.println("3.Read the document");
                System.out.println("4.Update the document");
                System.out.println("5.Delete the document");
                System.out.println("6.Drop the collection");
                System.out.println("7.Exit");
                System.out.print("Enter the choice:- ");
                ch=sc.nextInt();
                switch(ch)
                {
                    case 1:
                    	
                        
                        collectionName=db.createCollection(name, null);
                        System.out.println("COLLECTION CREATED SUCCESSFULLY");
                        doc=new BasicDBObject();
                        doc.put("title", "TOC");
                        doc.put("price",100);
                        collectionName.insert(doc);
                        break;                     
                    case 2:
                  
                        collectionName=db.createCollection(name, null);
                        doc=new BasicDBObject();
                        doc.put("title", "TOC");
                        doc.put("price",100);
                        collectionName.insert(doc);
                        break;
                    case 3:
                    	
                        collectionName=db.getCollection(name);
                        cursor=collectionName.find();
                        int i=1;
                        while(cursor.hasNext())
                        {
                            System.out.println("INSERTED DOCUMENTS ARE:- "+i);
                            System.out.println(cursor.next());
                            i++;
                        }
                        break;
                    case 4:
                    
                        collectionName=db.getCollection(name);
                        BasicDBObject query=new BasicDBObject();
                        query.put("price", 100);
                        cursor=collectionName.find(query);
                        while(cursor.hasNext())
                        {

                            DBObject updateDocument1 = cursor.next();
                            updateDocument1.put("title","hello world");
                            collectionName.save(updateDocument1);
                        }
                        break;
                    case 5:
                    	name=sc.next();
                        collectionName=db.getCollection(name);
                        DBObject obj=collectionName.findOne();
                        collectionName.remove(obj);
                        System.out.println("First document in the collection is deleted");
                        break;
                    case 6:
                    
                        collectionName=db.getCollection(name);
                        collectionName.drop();
                        System.out.println("Collection drop successfully");
                        break;
                }
            }while(ch!=7);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    
}
