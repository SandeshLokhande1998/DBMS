package Connection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
 
 
public class conn1 {
    
    public static void main(String[] args) throws SQLException {
 
        String url ="jdbc:mysql://localhost:3306/mysql"; //update connection string
        
        String user = "root";//add your db user id here
        String password = "1234";//add your db password here
        
        Connection conn = DriverManager.getConnection(url, user, password);
        System.out.println("Successfully connected");
        
      //create employee record into database
        Statement stmt = conn.createStatement();
        int rows = stmt.executeUpdate("CREATE TABLE employee1 (id int(11) NOT NULL AUTO_INCREMENT,age int(11) NOT NULL,name varchar(255) DEFAULT NULL, PRIMARY KEY (id))");
        System.out.println("table created = "+ rows);
        
        
        //insert employee record into database
        Statement stmt1 = conn.createStatement();
        int rows1 = stmt1.executeUpdate("insert into employee1(age,name) values(23,'James')");
        System.out.println("Rows inserted = "+ rows1);
        
        //update employee record
        rows= stmt.executeUpdate("Update employee1 set age=31 where name='James'");
        System.out.println("Rows updated = "+ rows);
        
        //read employee records
        ResultSet rs = stmt.executeQuery("Select * from employee1");
        while(rs.next()){
            System.out.println("Emp Id : " + rs.getInt("id") + ", Name : " + rs.getString("name") + ", Age : " + rs.getInt("age"));
        }
        
        //delete employee record
        rows = stmt.executeUpdate("delete from employee1 where name = 'James'");
        System.out.println("Rows deleted = "+ rows);
    }
    
 
}
