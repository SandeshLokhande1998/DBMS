31.Write a Stored Procedure namely proc_Grade for the categorization of student. If marks scored by students in examination is <=1500 and marks>=990 then student will be placed in distinction category if marks scored are between 989 and900 category is first class, if marks 899 and 825 category is Higher Second Class .

Consider Schema as Stud_Marks(name, total_marks) and Result(Roll,Name, Class) 

 create procedure proc_grade(in rollno int,in stud_name varchar(50))
    begin
    declare marks int;
    declare stud_class varchar(50);
    select tot_marks from stud_marks where stud_nm=stud_name into marks;
    if(marks<=1500 AND marks>=990) then
    set stud_class='distinction';
    elseif(marks<=989 AND marks>=900) then
    set stud_class='first class';
   elseif(marks<=899 AND marks>=825) then
    set stud_class='higher second class';
    else
    set stud_class='fail';
    end if;
    insert into result values(rollno,stud_name,stud_class);
     end //


mysql> create database d31;
Query OK, 1 row affected (0.00 sec)

mysql> use d31;
Database changed


mysql>  create table stud_marks(stud_nm varchar(20),tot_marks int);
   
Query OK, 0 rows affected (0.29 sec)

mysql> create table result(roll_no int,stud_nm varchar(20),class varchar(20));    
Query OK, 0 rows affected (0.26 sec)




mysql>  insert into stud_marks values('abc',1100),('xyz',1200),('mno',1000),('efg',950),('ghj',850);
    




mysql> desc stud_marks;
    -> //
+-----------+-------------+------+-----+---------+-------+
| Field     | Type        | Null | Key | Default | Extra |
+-----------+-------------+------+-----+---------+-------+
| stud_nm   | varchar(20) | YES  |     | NULL    |       |
| tot_marks | int(11)     | YES  |     | NULL    |       |
+-----------+-------------+------+-----+---------+-------+
2 rows in set (0.00 sec)

mysql> desc result;
    -> //
+---------+-------------+------+-----+---------+-------+
| Field   | Type        | Null | Key | Default | Extra |
+---------+-------------+------+-----+---------+-------+
| roll_no | int(11)     | YES  |     | NULL    |       |
| stud_nm | varchar(20) | YES  |     | NULL    |       |
| class   | varchar(20) | YES  |     | NULL    |       |
+---------+-------------+------+-----+---------+-------+
3 rows in set (0.00 sec)




mysql> delimiter //
mysql>  create procedure proc_grade(in rollno int,in stud_name varchar(50))
    ->     begin
    ->     declare marks int;
    ->     declare stud_class varchar(50);
    ->     select tot_marks from stud_marks where stud_nm=stud_name into marks;
    ->     if(marks<=1500 AND marks>=990) then
    ->     set stud_class='distinction';
    ->     elseif(marks<=989 AND marks>=900) then
    ->     set stud_class='first class';
    ->    elseif(marks<=899 AND marks>=825) then
    ->     set stud_class='higher second class';
    ->     else
    ->     set stud_class='fail';
    ->     end if;
    ->     insert into result values(rollno,stud_name,stud_class);
    ->      end //
Query OK, 0 rows affected (0.00 sec)



mysql> call proc_grade(1,"abc");
Query OK, 1 row affected (0.05 sec)


mysql> call proc_grade(2,"efg");
Query OK, 1 row affected (0.05 sec)



mysql>  call proc_grade(3,"ghj");
   
Query OK, 1 row affected (0.04 sec)


mysql>  call proc_grade(4,"mno");
Query OK, 1 row affected (0.05 sec)



mysql> call proc_grade(5,"xyz");

Query OK, 1 row affected (0.06 sec)

mysql> select * from result;
+---------+---------+---------------------+
| roll_no | stud_nm | class               |
+---------+---------+---------------------+
|       1 | abc     | distinction         |
|       2 | efg     | first class         |
|       3 | ghj     | higher second class |
|       4 | mno     | distinction         |
|       5 | xyz     | distinction         |
+---------+---------+---------------------+
5 rows in set (0.00 sec)

