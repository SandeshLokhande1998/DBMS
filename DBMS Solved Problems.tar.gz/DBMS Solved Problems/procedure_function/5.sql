Create tables CitiesIndia(pincode,nameofcity,earliername,area,population,avgrainfall) 
Categories(Type,pincode) Note:- Enter data only in CitiesIndia
Write PL/SQL Procedure & function to find the population density of the cities. If the population density is above 3000 then Type of city must be entered as High Density in Category table. Between 2999 to 1000 as Moderate and below 999 as Low Density. Error must be displayed for population less than 10 or greater than 25718.



create procedure compute_density(in population int,out density varchar(20))
     begin
     if population>3000 then
     set density="High Density";
     elseif population<=2999 and population>=1000 then 
     set density="Moderate";
     elseif population<=999 then 
     set density="Low Density";
     end if;
     end;
     //


create function add_cate(nm_city varchar(20)) returns int
          begin 
          declare pop int;
          declare pin int;
         declare ans varchar(20);
         select cities_india.population,cities_india.pincode into pop,pin from cities_india where cities_india.nm_city=nm_city;
         call compute_density(pop,@ans);
         insert into categories values(@ans,pincode);
          return pop;
          end;
         //




mysql> create database d5;
Query OK, 1 row affected (0.00 sec)

mysql> use d5 ;
Database changed


mysql> create table cities_india(pincode int, nm_city varchar(20),earli_nm varchar(20),area varchar(20),population int,avg_rainfall int );
Query OK, 0 rows affected (0.27 sec)

mysql> desc cities_india;
+--------------+-------------+------+-----+---------+-------+
| Field        | Type        | Null | Key | Default | Extra |
+--------------+-------------+------+-----+---------+-------+
| pincode      | int(11)     | YES  |     | NULL    |       |
| nm_city      | varchar(20) | YES  |     | NULL    |       |
| earli_nm     | varchar(20) | YES  |     | NULL    |       |
| area         | varchar(20) | YES  |     | NULL    |       |
| population   | int(11)     | YES  |     | NULL    |       |
| avg_rainfall | int(11)     | YES  |     | NULL    |       |
+--------------+-------------+------+-----+---------+-------+
6 rows in set (0.00 sec)

mysql> create table categories(type varchar(20),pincode int);
Query OK, 0 rows affected (0.25 sec)

mysql> desc categories;
+---------+-------------+------+-----+---------+-------+
| Field   | Type        | Null | Key | Default | Extra |
+---------+-------------+------+-----+---------+-------+
| type    | varchar(20) | YES  |     | NULL    |       |
| pincode | int(11)     | YES  |     | NULL    |       |
+---------+-------------+------+-----+---------+-------+
2 rows in set (0.00 sec)



mysql>  insert into cities_india values(411048,'kondhwa','bk','pune',12000,250),
(411049,'ambegaon','a_bk','pune',13000,250),(411050,'warje','W-bk','pune',14000,350),(411051,'magarwadi','wadi','pune',15000,250);
Query OK, 4 rows affected (0.08 sec)
Records: 4  Duplicates: 0  Warnings: 0

mysql> delimiter //
mysql> create procedure compute_density(in population int,out density varchar(20))
    ->      begin
    ->      if population>3000 then
    ->      set density="High Density";
    ->      elseif population<=2999 and population>=1000 then 
    ->      set density="Moderate";
    ->      elseif population<=999 then 
    ->      set density="Low Density";
    ->      end if;
    ->      end;
    ->      //
Query OK, 0 rows affected (0.00 sec)

mysql>delimiter //
mysql> create function add_cate(nm_city varchar(20)) returns int
    ->           begin 
    ->           declare pop int;
    ->           declare pin int;
    ->          declare ans varchar(20);
    ->          select cities_india.population,cities_india.pincode into pop,pin from cities_india where cities_india.nm_city=nm_city;
    ->          call compute_density(pop,@ans);
    ->          insert into categories values(@ans,pincode);
    ->           return pop;
    ->           end;
    ->          //
Query OK, 0 rows affected (0.00 sec)

mysql> 
mysql> select add_cate('kondhwa');
   
+---------------------+
| add_cate('kondhwa') |
+---------------------+
|               12000 |
+---------------------+
1 row in set (0.05 sec)

mysql> select add_cate('ambegaon');
  
+----------------------+
| add_cate('ambegaon') |
+----------------------+
|                13000 |
+----------------------+
1 row in set (0.07 sec)

mysql> select * from categories;
 
+--------------+---------+
| type         | pincode |
+--------------+---------+
| High Density |    NULL |
| High Density |    NULL |
| High Density |    NULL |
| High Density |    NULL |
+--------------+---------+
4 rows in set (0.00 sec)






