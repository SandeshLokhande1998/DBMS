29. Writ a PL/SQL procedure to find the number of students ranging from 100-70%, 69-60%, 59-50% & below 49% in each course from the student_coursetable given by the procedure as parameter.
Schema: Student (ROLL_NO ,COURSE, COURSE_COD ,SEM ,TOTAL_MARKS, PERCENTAGE)


--------------------------------------------------------------------------------------
this can be done by two ways
--------------------------------------------------------------------------------first way
create procedure check_percent(course_name varchar(20))              
begin
declare count100_70 int default 0;
declare count69_60 int default 0;
declare count59_50 int default 0;
declare count49 int default 0;
declare percent float;
declare exit_loop BOOLEAN;
declare c1 cursor for select percentage from student where course=course_name;
declare continue handler for NOT FOUND SET exit_loop=TRUE;
open c1;
c1_loop:LOOP
fetch c1 into percent;
if(percent<=100.00 AND percent>=70.00) then
set count100_70=count100_70+1;
elseif(percent<=69.00 AND percent>=60.00) then
set count69_60=count69_60+1;
elseif(percent<=59.00 AND percent>=50.00) then
set count59_50=count59_50+1;
elseif(percent>=49) then
set count49=count49+1;
end if;
if(exit_loop) then
close c1;
leave c1_loop;
end if;
end LOOP c1_loop;
select count100_70;
select count69_60;
select count59_50;
select count49;
end //



-----------------------------------------------------------------------------------another way
mysql create procedure check_per(course_name varchar(20))
    begin
    declare count100_70 int default 0;
    declare count69_60 int default 0;
    declare count59_50 int default 0;
    declare count49 int default 0;
    select count(percentage) from student where course=course_name AND (percentage<=100 AND percentage>=70) into count100_70;
    select count(percentage) from student where course=course_name AND (percentage<=69 AND percentage>=60) into count69_60;
     select count(percentage) from student where course=course_name AND (percentage<=59 AND percentage>=50) into count59_50;
    select count(percentage) from student where course=course_name AND (percentage<=49) into count49;
     select count100_70;
     select count69_60;
    select count59_50;
    select count49;
     end //

----------------------------------------------------------------------------------------------------
Actual implementation
---------------------------------------------------------------------------------------------------




mysql> create database d29;
Query OK, 1 row affected (0.00 sec)

mysql> use d29;
Database changed

mysql> create table student(roll_no int, course varchar(20), course_code int , sem varchar(20) ,tot_marks int, percentage int );
Query OK, 0 rows affected (0.30 sec)




mysql> insert into student values(1,'te-2015',1001,'fifth',405,83.82),(2,'te-2015',1001,'fifth',450,85),(3,'te-2015',1001,'fifth',400,80),(4,'te-2015',1001,'fifth',400,80),(4,'se-2015',1001,'fifth',400,80),(4,'be-2015',1001,'fifth',400,80),(2,'se-2015',1001,'fifth',440,84),(2,'be-2015',1001,'fifth',440,84),(1,'se-2015',1001,'fifth',405,83.82),(1,'be-2015',1001,'fifth',405,83.82);
Query OK, 10 rows affected (0.05 sec)
Records: 10  Duplicates: 0  Warnings: 0

mysql> delimiter //
mysql> 
mysql> create procedure check_percent(course_name varchar(20))
    -> begin
    -> declare count100_70 int default 0;
    -> declare count69_60 int default 0;
    -> declare count59_50 int default 0;
    -> declare count49 int default 0;
    -> declare percent float;
    -> declare exit_loop BOOLEAN;
    -> declare c1 cursor for select percentage from student where course=course_name;
    -> declare continue handler for NOT FOUND SET exit_loop=TRUE;
    -> open c1;
    -> c1_loop:LOOP
    -> fetch c1 into percent;
    -> if(percent<=100.00 AND percent>=70.00) then
    -> set count100_70=count100_70+1;
    -> elseif(percent<=69.00 AND percent>=60.00) then
    -> set count69_60=count69_60+1;
    -> elseif(percent<=59.00 AND percent>=50.00) then
    -> set count59_50=count59_50+1;
    -> elseif(percent>=49) then
    -> set count49=count49+1;
    -> end if;
    -> if(exit_loop) then
    -> close c1;
    -> leave c1_loop;
    -> end if;
    -> end LOOP c1_loop;
    -> select count100_70;
    -> select count69_60;
    -> select count59_50;
    -> select count49;
    -> end //
Query OK, 0 rows affected (0.07 sec)



mysql> select * from student;
    
+---------+---------+-------------+-------+-----------+------------+
| roll_no | course  | course_code | sem   | tot_marks | percentage |
+---------+---------+-------------+-------+-----------+------------+
|       1 | te-2015 |        1001 | fifth |       405 |         84 |
|       2 | te-2015 |        1001 | fifth |       450 |         85 |
|       3 | te-2015 |        1001 | fifth |       400 |         80 |
|       4 | te-2015 |        1001 | fifth |       400 |         80 |
|       4 | se-2015 |        1001 | fifth |       400 |         80 |
|       4 | be-2015 |        1001 | fifth |       400 |         80 |
|       2 | se-2015 |        1001 | fifth |       440 |         84 |
|       2 | be-2015 |        1001 | fifth |       440 |         84 |
|       1 | se-2015 |        1001 | fifth |       405 |         84 |
|       1 | be-2015 |        1001 | fifth |       405 |         84 |
+---------+---------+-------------+-------+-----------+------------+
10 rows in set (0.00 sec)



mysql> call check_percent("se-2015");
+-------------+
| count100_70 |
+-------------+
|           4 |
+-------------+
1 row in set (0.00 sec)

+------------+
| count69_60 |
+------------+
|          0 |
+------------+
1 row in set (0.00 sec)

+------------+
| count59_50 |
+------------+
|          0 |
+------------+
1 row in set (0.00 sec)

+---------+
| count49 |
+---------+
|       0 |
+---------+
1 row in set (0.00 sec)

Query OK, 0 rows affected (0.00 sec)


