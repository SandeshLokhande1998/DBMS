30. Write a PL/SQL block of code using Cursor, that will merge the data available in the newly created table N_RollCall with the data available in the table O_RollCall. If the data in the first table already exist in the second table then that data should be skipped. 






 create procedure merger()
 begin
 declare rno int;
 declare end_loop boolean;
 declare c1 cursor for select rollno from o_rollcall;
 declare continue handler for NOT FOUND set end_loop=true;
 open c1;
 c1_loop:LOOP
 fetch c1 into rno;
 if not exists(select * from n_rollcall where rollno=rno) then
 insert into n_rollcall select * from o_rollcall where rollno=rno;
 end if;
 if end_loop then
 close c1;
 leave c1_loop;
 end if;
     end LOOP c1_loop;
     end //

mysql> create database d30;
Query OK, 1 row affected (0.00 sec)

mysql> use d30;
Database changed
mysql> create table o_rollcall(rollno int,class varchar(20));
Query OK, 0 rows affected (0.30 sec)

mysql> insert into o_rollcall values(1,"a"),(2,"b"),(3,"c"),(4,"d"),(5,"e"),(5,"e"),(1,"a"),(6,"f");
Query OK, 8 rows affected (0.15 sec)
Records: 8  Duplicates: 0  Warnings: 0

mysql> create table n_rollcall(rollno int,class varchar(20));
Query OK, 0 rows affected (0.26 sec)

mysql> delimiter //
mysql> create procedure merger()
    ->     begin
    ->      declare rno int;
    ->      declare end_loop boolean;
    ->      declare c1 cursor for select rollno from o_rollcall;
    ->      declare continue handler for NOT FOUND set end_loop=true;
    ->      open c1;
    ->      c1_loop:LOOP
    ->      fetch c1 into rno;
    ->      if not exists(select * from n_rollcall where rollno=rno) then
    ->     insert into n_rollcall select * from o_rollcall where rollno=rno;
    ->      end if;
    ->      if end_loop then
    ->      close c1;
    ->     leave c1_loop;
    ->      end if;
    ->      end LOOP c1_loop;
    ->      end //
Query OK, 0 rows affected (0.00 sec)

mysql> call merger();

Query OK, 0 rows affected (0.31 sec)

mysql> select * from o_rollcall;

+--------+-------+
| rollno | class |
+--------+-------+
|      1 | a     |
|      2 | b     |
|      3 | c     |
|      4 | d     |
|      5 | e     |
|      5 | e     |
|      1 | a     |
|      6 | f     |
+--------+-------+
8 rows in set (0.00 sec)

mysql> select * from n_rollcall;

+--------+-------+
| rollno | class |
+--------+-------+
|      1 | a     |
|      1 | a     |
|      2 | b     |
|      3 | c     |
|      4 | d     |
|      5 | e     |
|      5 | e     |
|      6 | f     |
+--------+-------+
8 rows in set (0.00 sec)



