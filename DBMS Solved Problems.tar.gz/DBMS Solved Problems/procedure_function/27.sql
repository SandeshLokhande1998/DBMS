27: Write a PL/SQL code to calculate tax for an employee of an organization ABC and to display his/her name & tax, by creating a table under employee database as below:
Employee_salary(emp_no,basic,HRA,DA,Total_deduction,net_salary,gross_Salary)



delimiter //
create procedure proc_cal_tax(in empno int)
begin
declare net_sal int;
declare sal int;
declare diff int;
declare tax int;
declare ename varchar(20);
select net_salary from emp_sal where eno=empno into sal;
select name from emp_sal where eno=empno into ename;
set net_sal=sal*12;
if(net_sal<=250000) then
set tax=0;
elseif(net_sal>=250000) then
set diff=net_sal-250000;
set tax=diff/10;
end if;
insert into pay_tax values(empno,tax);
end //
delimiter ;





CREATE TABLE `emp_sal` (
  `eno` int(11) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `basic` int(11) DEFAULT NULL,
  `hra` int(11) DEFAULT NULL,
  `da` int(11) DEFAULT NULL,
  `tot_deduction` int(11) DEFAULT NULL,
  `net_salary` int(11) DEFAULT NULL,
  `gross_salary` int(11) DEFAULT NULL
) ;




INSERT INTO `emp_sal` VALUES (1,'suman',15000,4000,1000,5000,15000,20000),(2,'radha',31000,8000,1000,5000,35000,40000),(3,'ram',14000,4000,1000,5000,15000,19000),(4,'raju',14000,4000,1000,5000,15000,19000),(5,'dinesh',13000,4000,1000,5000,45000,18000);



CREATE TABLE `pay_tax` (
  `eno` int(11) DEFAULT NULL,
  `pay_tax` int(11) DEFAULT NULL
) ;
mysql>delimiter //
mysql> create procedure proc_cal_tax(in empno int)
    -> begin
    -> declare net_sal int;
    -> declare sal int;
    -> declare diff int;
    -> declare tax int;
    -> declare ename varchar(20);
    -> select net_salary from emp_sal where eno=empno into sal;
    -> select name from emp_sal where eno=empno into ename;
    -> set net_sal=sal*12;
    -> if(net_sal<=250000) then
    -> set tax=0;
    -> elseif(net_sal>=250000) then
    -> set diff=net_sal-250000;
    -> set tax=diff/10;
    -> end if;
    -> insert into pay_tax values(empno,tax);
    -> end //
Query OK, 0 rows affected (0.00 sec)

mysql> delimiter ;
mysql> call proc_cal_tax(5);
Query OK, 1 row affected (0.07 sec)

mysql> select * from pay_tax;
+------+---------+
| eno  | pay_tax |
+------+---------+
|    5 |   29000 |
+------+---------+
1 row in set (0.00 sec)

mysql> 

