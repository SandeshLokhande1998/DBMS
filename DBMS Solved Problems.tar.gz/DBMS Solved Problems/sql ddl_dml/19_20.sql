19:Implement all SQL DML opeartions with operators, functions, and set operator for
given schema:
Account(Acc_no, branch_name,balance)
branch(branch_name,branch_city,assets)
customer(cust_name,cust_street,cust_city)
Depositor(cust_name,acc_no)
Loan(loan_no,branch_name,amount)
Borrower(cust_name,loan_no)
Create above tables with appropriate constraints like primary key, foreign key, check
constrains, not null etc.
Solve following query:

1.Find all customers who have an account or loan or both at bank.
2.Find all customers who have both account and loan at bank.
3.Find all customer who have account but no loan at the bank.
4.Find average account balance at Akurdi branch.

20:Implement all SQL DML operations with operators, functions, and set operator for
given schema:
Account(Acc_no, branch_name,balance)
branch(branch_name,branch_city,assets)
customer(cust_name,cust_street,cust_city)
Depositor(cust_name,acc_no)
Loan(loan_no,branch_name,amount)
Borrower(cust_name,loan_no)

mysql> show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| SMPS               |
| abd                |
| airplane           |
| company            |
| d11                |
| d14                |
| emp                |
| join1              |
| mysql              |
| performance_schema |
| sample             |
| sp                 |
| sys                |
+--------------------+
14 rows in set (0.14 sec)

mysql> use d14;

Database changed
mysql> show tables;
+---------------+
| Tables_in_d14 |
+---------------+
| acc           |
| borrower      |
| branch        |
| customer      |
| depositor     |
| loan          |
+---------------+
6 rows in set (0.00 sec)

mysql> select * from borrower union select * from depositor;
+-----------+---------+
| cust_name | loan_no |
+-----------+---------+
| abc       |      10 |
| pqr       |      11 |
| abc       |     101 |
| mno       |     102 |
| pqr       |     103 |
+-----------+---------+
5 rows in set (0.00 sec)


mysql> select * from borrower union all select * from depositor;
+-----------+---------+
| cust_name | loan_no |
+-----------+---------+
| abc       |      10 |
| pqr       |      11 |
| abc       |     101 |
| mno       |     102 |
| pqr       |     103 |
+-----------+---------+
5 rows in set (0.00 sec)

mysql> select cust_name  from borrower union all select cust_name from depositor;
+-----------+
| cust_name |
+-----------+
| abc       |
| pqr       |
| abc       |
| mno       |
| pqr       |
+-----------+
5 rows in set (0.00 sec)

mysql> select distinct cust_name from borrower inner join depositor using(cust_name);
+-----------+
| cust_name |
+-----------+
| abc       |
| pqr       |
+-----------+
2 rows in set (0.05 sec)

mysql> select distinct cust_name from depositor left join borrower using(cust_name);
+-----------+
| cust_name |
+-----------+
| abc       |
| pqr       |
| mno       |
+-----------+
3 rows in set (0.00 sec)

mysql> select distinct cust_name from borrower left join depositor using(cust_name);
+-----------+
| cust_name |
+-----------+
| abc       |
| pqr       |
+-----------+
2 rows in set (0.00 sec)

mysql> select distinct cust_name from borrower left join depositor using(cust_name)where borrower.cust_name is NULL;
Empty set (0.00 sec)

mysql> select avg(balance) from acc where branch_name='Pune';
+--------------+
| avg(balance) |
+--------------+
|         NULL |
+--------------+
1 row in set (0.00 sec)

mysql> select avg(balance) from acc where branch_name='pune';
+--------------+
| avg(balance) |
+--------------+
|         NULL |
+--------------+
1 row in set (0.00 sec)

mysql> select avg(balance) from acc where branch_name='vadgaon';
+--------------+
| avg(balance) |
+--------------+
|         NULL |
+--------------+
1 row in set (0.00 sec)

mysql> select * from acc;
+--------+-------------+---------+
| acc_no | branch_name | balance |
+--------+-------------+---------+
|    101 | bobm        |   20000 |
|    102 | bobm        |   40000 |
|    103 | bobn        |   40000 |
|    104 | bobn        |   70000 |
+--------+-------------+---------+
4 rows in set (0.00 sec)

mysql> insert into acc values(105,'akurdi',90000);
Query OK, 1 row affected (0.05 sec)

mysql> insert into acc values(106,'akurdi',50000);
Query OK, 1 row affected (0.04 sec)

mysql> insert into acc values(107,'akurdi',60000);
Query OK, 1 row affected (0.34 sec)

mysql> select avg(balance) from acc where branch_name='akurdi';
+--------------+
| avg(balance) |
+--------------+
|   66666.6667 |
+--------------+
1 row in set (0.00 sec)

mysql> select sum(amount) as loan from loan;
+-------+
| loan  |
+-------+
| 58252 |
+-------+
1 row in set (0.00 sec)



mysql> delete from borrower where loan_no in(select loan_no from loan where amount>=1300 or amount<=1500);
Query OK, 2 rows affected (0.06 sec)

mysql> select * from loan;
+---------+-------------+--------+
| loan_no | branch_name | amount |
+---------+-------------+--------+
|      10 | bobn        |  57676 |
|      11 | bobm        |    576 |
+---------+-------------+--------+
2 rows in set (0.00 sec)

mysql> delete from loan where amount>=1300 or amount<=1500;
Query OK, 2 rows affected (0.05 sec)

mysql> select * from loan;
Empty set (0.00 sec)

mysql> delete acc,branch from acc inner join branch on branch.branch_name=acc.branch_name where acc.branch_name='Akurdi';
Query OK, 0 rows affected (0.00 sec)

mysql> select * from branch;
+-------------+-------------+----------+
| branch_name | branch_city | assets   |
+-------------+-------------+----------+
| bobm        | mumbai      | 45000000 |
| bobn        | nashik      | 45000000 |
| bobp        | pune        | 49990000 |
+-------------+-------------+----------+
3 rows in set (0.00 sec)

mysql> insert into branch values('Akurdi','Pune',8000000);
Query OK, 1 row affected (0.05 sec)

mysql> insert into branch values('Akurdi','Pune',9000000);
Query OK, 1 row affected (0.06 sec)

mysql> insert into branch values('Akurdi','Pune',1000000);
Query OK, 1 row affected (0.04 sec)

mysql> delete acc,branch from acc inner join branch on branch.branch_name=acc.branch_name where acc.branch_name='Akurdi';
Query OK, 6 rows affected (0.12 sec)

mysql> select * from acc;
+--------+-------------+---------+
| acc_no | branch_name | balance |
+--------+-------------+---------+
|    101 | bobm        |   20000 |
|    102 | bobm        |   40000 |
|    103 | bobn        |   40000 |
|    104 | bobn        |   70000 |
+--------+-------------+---------+
4 rows in set (0.00 sec)

mysql> select * from branch;
+-------------+-------------+----------+
| branch_name | branch_city | assets   |
+-------------+-------------+----------+
| bobm        | mumbai      | 45000000 |
| bobn        | nashik      | 45000000 |
| bobp        | pune        | 49990000 |
+-------------+-------------+----------+
3 rows in set (0.00 sec)


