14: Implement all SQL DML operations with operators, functions, and set operator for
given schema:
Account(Acc_no, branch_name,balance)
branch(branch_name,branch_city,assets)
customer(cust_name,cust_street,cust_city)
Depositor(cust_name,acc_no)
Loan(loan_no,branch_name,amount)
Borrower(cust_name,loan_no)




mysql> create database d14;
Query OK, 1 row affected (0.01 sec)

mysql> use d14;
Database changed
			//////////////Accoun table///////////////

mysql> create table acc(acc_no int primary key not null,branch_name varchar(20),balance int);
Query OK, 0 rows affected (0.24 sec)

mysql> insert into acc values(101,"bobm",20000);                              Query OK, 1 row affected (0.04 sec)

mysql> insert into acc values(102,"bobm",40000);
Query OK, 1 row affected (0.07 sec)

mysql> insert into acc values(103,"bobn",40000);
Query OK, 1 row affected (0.05 sec)

mysql> insert into acc values(104,"bobn",70000);
Query OK, 1 row affected (0.07 sec)



			////////////// Branch table///////////////

mysql> create table branch(branch_name varchar(20),branch_city varchar(20),assets int);
Query OK, 0 rows affected (0.28 sec)


mysql> insert into branch values("bobm","mumbai",45000000);
Query OK, 1 row affected (0.04 sec)

mysql> insert into branch values("bobn","nashik",45000000);
Query OK, 1 row affected (0.06 sec)

mysql> insert into branch values("bobp","pune",49990000);
Query OK, 1 row affected (0.05 sec)

				////////////// customer table///////////////
mysql> create table customer(cust_name varchar(50),cust_street varchar(20),cust_city varchar(20));
Query OK, 0 rows affected (0.22 sec)

mysql> insert into customer values("abc","sr_road","nashik");
Query OK, 1 row affected (0.04 sec)

mysql> insert into customer values("mno","sb oad","pune");
Query OK, 1 row affected (0.04 sec)

mysql> insert into customer values("pqr","nb road","mumbai");
Query OK, 1 row affected (0.04 sec)

					////////////// Depositor table///////////////


mysql> mysql> create table depositor(cust_name varchar(20),acc_no int, foreign key(acc_no) references acc(acc_no));
Query OK, 0 rows affected (0.28 sec)

mysql> insert into depositor values("abc",101);
Query OK, 1 row affected (0.04 sec)

mysql> insert into depositor values("mno",102);
Query OK, 1 row affected (0.03 sec)

mysql> insert into depositor values("pqr",103);
Query OK, 1 row affected (0.03 sec)

				////////////// loan table///////////////

mysql> create table loan(loan_no int primary key,branch_name varchar(20),amount int);
Query OK, 0 rows affected (0.24 sec)

mysql> insert into loan values(10,"bobn",57676);
Query OK, 1 row affected (0.04 sec)

mysql> insert into loan values(11,"bobm",576);
Query OK, 1 row affected (0.05 sec)

					////////////// Borrower table///////////////
mysql> create table borrower(cust_name varchar(20),loan_no int,foreign key(loan_no) references loan(loan_no));
Query OK, 0 rows affected (0.26 sec)



mysql> insert into borrower values("abc",10);
Query OK, 1 row affected (0.04 sec)

mysql> insert into borrower values("pqr",11);
Query OK, 1 row affected (0.03 sec)

mysql> select avg(balance) from acc group by branch_name;
+--------------+
| avg(balance) |
+--------------+
|   30000.0000 |
|   55000.0000 |
+--------------+
2 rows in set (0.00 sec)

mysql> select avg(balance),branch_name from acc group by branch_name;
+--------------+-------------+
| avg(balance) | branch_name |
+--------------+-------------+
|   30000.0000 | bobm        |
|   55000.0000 | bobn        |
+--------------+-------------+
2 rows in set (0.00 sec)



mysql> select count(acc_no) from acc where exists(select acc_no from depositor); 
+---------------+
| count(acc_no) |
+---------------+
|             4 |
+---------------+
1 row in set (0.00 sec)

mysql> select branch_name  from acc group by branch_name having avg(balance)>1200;
+-------------+
| branch_name |
+-------------+
| bobm        |
| bobn        |
+-------------+
2 rows in set (0.01 sec)

mysql> select count(cust_name)as count from customer;
+-------+
| count |
+-------+
|     3 |
+-------+
1 row in set (0.00 sec)

mysql> 

