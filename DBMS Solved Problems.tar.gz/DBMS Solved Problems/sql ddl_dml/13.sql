13:Create the instance of the COMPANYwhich consists of the following tables:
EMPLOYEE(Fname, Minit, Lname, Ssn, Bdate, Address, Sex, Salary, Dno)
DEPARTEMENT(Dname, Dnumber, Mgr_ssn, Mgr_start_date)
DEPT_LOCATIONS(Dnumber, Dlocation)
PROJECT(Pname, Pnumber, Plocation, Dnum)
WORKS_ON(Essn, Pno, Hours)
DEPENDENT(Essn, Dependent_name, Sex, Bdate, Relationship)
Perform following queries
1.
For every project located in ‘Stafford’, list the project number, the controlling
department number, and the department manager’s last name,address, and birth
date.
2.
Make a list of all project numbers for projects that involve an employee whose last
name is ‘Smith’, either as a worker or as a manager of the department that controls
the project.
3.
Retrieve all employees whose address is in Houston, Texas.
4.
Show the resulting salaries if every employee working on the ‘ProductX’ project is
given a 10 percent raise.



mysql> create datbase company;
Query OK, 1 row affected (0.00 sec)

mysql> use company;
Database changed
			//////////emp table////////////////
mysql> create table emp(name varchar(50),minit varchar(50),lname varchar(50),ssn int,bdate date,address varchar(100),sex varchar(20),salary int, dno int);
Query OK, 0 rows affected (0.26 sec)

mysql> desc emp;
+---------+--------------+------+-----+---------+-------+
| Field   | Type         | Null | Key | Default | Extra |
+---------+--------------+------+-----+---------+-------+
| name    | varchar(50)  | YES  |     | NULL    |       |
| minit   | varchar(50)  | YES  |     | NULL    |       |
| lname   | varchar(50)  | YES  |     | NULL    |       |
| ssn     | int(11)      | YES  |     | NULL    |       |
| bdate   | date         | YES  |     | NULL    |       |
| address | varchar(100) | YES  |     | NULL    |       |
| sex     | varchar(20)  | YES  |     | NULL    |       |
| salary  | int(11)      | YES  |     | NULL    |       |
| dno     | int(11)      | YES  |     | NULL    |       |
+---------+--------------+------+-----+---------+-------+
9 rows in set (0.00 sec)

mysql> insert into emp values('Parth','d','Carol',1,'1997-28-10','new plot','m',80000,1);
ERROR 1292 (22007): Incorrect date value: '1997-28-10' for column 'bdate' at row 1
mysql> insert into emp values('Parth','d','Carol',1,"1997-28-10",'new plot','m',80000,1);
ERROR 1292 (22007): Incorrect date value: '1997-28-10' for column 'bdate' at row 1
mysql> insert into emp values('Parth','d','Carol',1,'1998-28-10','new plot','m',80000,1);
ERROR 1292 (22007): Incorrect date value: '1998-28-10' for column 'bdate' at row 1
mysql> insert into emp values('Parth','d','Carol',1,'1998-10-28','new plot','m',80000,1);
Query OK, 1 row affected (0.04 sec)

mysql> insert into emp values('swap','d','Nik',2,'1997-10-28','new plot','m',70000,2);
Query OK, 1 row affected (0.04 sec)

mysql> insert into emp values('shubh','g','kulkarni',3,'1997-09-28','new plot','m',60000,3);
Query OK, 1 row affected (0.03 sec)

mysql> select * from emp;
+-------+-------+----------+------+------------+----------+------+--------+------+
| name  | minit | lname    | ssn  | bdate      | address  | sex  | salary | dno  |
+-------+-------+----------+------+------------+----------+------+--------+------+
| Parth | d     | Carol    |    1 | 1998-10-28 | new plot | m    |  80000 |    1 |
| swap  | d     | Nik      |    2 | 1997-10-28 | new plot | m    |  70000 |    2 |
| shubh | g     | kulkarni |    3 | 1997-09-28 | new plot | m    |  60000 |    3 |
+-------+-------+----------+------+------------+----------+------+--------+------+
3 rows in set (0.00 sec)

			///////////project table///////////

mysql> create table project(pname varchar(20),pnumber int,dnumber int);
Query OK, 0 rows affected (0.21 sec)

mysql> alter table project add column plocation varchar(20);
Query OK, 0 rows affected (0.63 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> insert into project values('productx'10,1,'stafford');
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '10,1,'stafford')' at line 1
mysql> insert into project values('productx',10,1,'stafford');
Query OK, 1 row affected (0.04 sec)

mysql> insert into project values('producty',11,1,'stafford');
Query OK, 1 row affected (0.03 sec)

mysql> insert into project values('productz',12,2,'mit');
Query OK, 1 row affected (0.05 sec)

mysql> select * from project;
+----------+---------+---------+-----------+
| pname    | pnumber | dnumber | plocation |
+----------+---------+---------+-----------+
| productx |      10 |       1 | stafford  |
| producty |      11 |       1 | stafford  |
| productz |      12 |       2 | mit       |
+----------+---------+---------+-----------+
3 rows in set (0.00 sec)




mysql> select dnumber,pnumber,name,lname,bdate from project inner join emp on project.dnumber=emp.dno where plocation='stafford';
+---------+---------+-------+-------+------------+
| dnumber | pnumber | name  | lname | bdate      |
+---------+---------+-------+-------+------------+
|       1 |      10 | Parth | Carol | 1998-10-28 |
|       1 |      11 | Parth | Carol | 1998-10-28 |
+---------+---------+-------+-------+------------+
2 rows in set (0.00 sec)

mysql> insert into emp values('john','hamish','watson',4,'1887-10-28','new plot','m',60000,6);
Query OK, 1 row affected (0.03 sec)

mysql> select pnumber from project where dnumber=(select dno from emp where lname='watson');
Empty set (0.00 sec)

mysql> insert into project values('i',78,6,'mit');
Query OK, 1 row affected (0.04 sec)



mysql> select pnumber from project where dnumber=(select dno from emp where lname='watson');
+---------+
| pnumber |
+---------+
|      78 |
+---------+
1 row in set (0.01 sec)

mysql> select * from emp where address='Houston,tExam';
Empty set (0.00 sec)

mysql> create table works(essn int,pno int,hours int);
Query OK, 0 rows affected (0.27 sec)

mysql> insert into works values(1,10,10);
Query OK, 1 row affected (0.04 sec)

mysql> update emp set salary=salary+salary*0.1 where ssn=(select essn from works where pno=(select pnumber from project where pname='productx'));
Query OK, 1 row affected (0.04 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> select * from works;
+------+------+-------+
| essn | pno  | hours |
+------+------+-------+
|    1 |   10 |    10 |
+------+------+-------+
1 row in set (0.00 sec)

mysql> update emp set salary=salary+salary*0.1 where ssn=(select essn from works where pno=(select pnumber from project where pname='productx'));
Query OK, 1 row affected (0.03 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> select * from emp;
+-------+--------+----------+------+------------+----------+------+--------+------+
| name  | minit  | lname    | ssn  | bdate      | address  | sex  | salary | dno  |
+-------+--------+----------+------+------------+----------+------+--------+------+
| Parth | d      | Carol    |    1 | 1998-10-28 | new plot | m    |  96800 |    1 |
| swap  | d      | Nik      |    2 | 1997-10-28 | new plot | m    |  70000 |    2 |
| shubh | g      | kulkarni |    3 | 1997-09-28 | new plot | m    |  60000 |    3 |
| john  | hamish | watson   |    4 | 1887-10-28 | new plot | m    |  60000 |    6 |
+-------+--------+----------+------+------------+----------+------+--------+------+
4 rows in set (0.00
