21: Create the following tables.

Deposit (actno,cname,bname,amount,adate)
2. Branch (bname,city)
3. Customers (cname, city)
4. Borrow(loanno,cname,bname, amount)
Add primary key and foreign key wherever applicable.Insert data into the above
created tables.
1.Display account date of customers “ABC”.
2.Modify the size of attribute of amount in deposit
3.Display names of customers living in city pune.
4.Display name of the city where branch “OBC” is located.
5.
Find the number of tuples in the customer relation

22.Create following tables:

Deposit (actno,cname,bname,amount,adate)
 Branch (bname,city)
Customers (cname, city)
Borrow(loanno,cname,bname, amount)
Add primary key and foreign key wherever applicable.Insert data into the above created
tables.

1.Display customer name having living city Bombay and branch city Nagpur
2.Display customer name having same living city as their branch city
3.Display customer name who are borrowers as well as depositors and having living
city Nagpur.


mysql> create database d21;
Query OK, 1 row affected (0.00 sec)

mysql> use d21;
Database changed


///////////////////Deposit (actno,cname,bname,amount,adate)///////////////


mysql> create table deposit(accno int ,cname varchar(20),bname varchar(20),amount int, adate date,primary key(cname,bname));
Query OK, 0 rows affected (0.28 sec)


mysql> insert into deposit values(1,'nitesh','pimpri',4000,'2014-07-08');       
Query OK, 1 row affected (0.06 sec)

mysql> insert into deposit values(2,'ritesh','malvan',40000,'2014-07-08');      
Query OK, 1 row affected (0.05 sec)


mysql> insert into deposit values(3,'ritu','malvan',409000,'2014-09-08') ;
Query OK, 1 row affected (0.06 sec)

mysql> insert into deposit values(4,'abcd','abc',4090,'2018-09-08') ;
Query OK, 1 row affected (0.05 sec)

mysql> alter table deposit modify column amount varchar(100);
Query OK, 4 rows affected (0.86 sec)
Records: 4  Duplicates: 0  Warnings: 0

mysql> select adate from deposit where cname='abc';
Empty set (0.00 sec)

mysql> select adate from deposit where cname='ritu';
+------------+
| adate      |
+------------+
| 2014-09-08 |
+------------+
1 row in set (0.00 sec)




///////////////////////Branch (bname,city)////////////////////////////////

mysql> create table branch(bname varchar(20),city varchar(20));
Query OK, 0 rows affected (0.25 sec)

mysql> insert into branch values('uyr','nagpur');
Query OK, 1 row affected (0.04 sec)

mysql> insert into branch values('urr','nagpur');
Query OK, 1 row affected (0.06 sec)

mysql> insert into branch values('samtanagar','nagpur');
Query OK, 1 row affected (0.04 sec)

mysql> insert into branch values('samtar','bombay');
Query OK, 1 row affected (0.07 sec)

mysql> insert into branch values('sueje','bombay');
Query OK, 1 row affected (0.05 sec)

/////////////////////////Customers (cname, city)//////////////////////////



mysql> create table customers(cname varchar(20),city varchar(20));
Query OK, 0 rows affected (0.29 sec)


mysql> insert into customers values('nitesh','pune');
Query OK, 1 row affected (0.07 sec)

mysql> insert into customers values('shreyas','malvan');
Query OK, 1 row affected (0.05 sec)

mysql> insert into customers values('abc','bombay');
Query OK, 1 row affected (0.06 sec)

mysql> insert into customers values('cdy','bombay');
Query OK, 1 row affected (0.05 sec)

mysql> insert into customers values('tct','nagpur');
Query OK, 1 row affected (0.06 sec)

////////////////////////Borrow(loanno,cname,bname, amount)////////////////////
mysql> create table borrow(loanno int,cname varchar(20),bname varchar(20),amount int);
Query OK, 0 rows affected (0.26 sec)

mysql> insert into borrow values(10,'nilesh','pimpri',4644);
Query OK, 1 row affected (0.05 sec)

mysql> insert into borrow values(11,'abc','samtanagar',44644);
Query OK, 1 row affected (0.06 sec)








mysql> select cname from customers where city='pune';
+--------+
| cname  |
+--------+
| nitesh |
+--------+
1 row in set (0.00 sec)

mysql> select city from branch where bname='abc';
Empty set (0.00 sec)

mysql> select * from branch;
+------------+--------+
| bname      | city   |
+------------+--------+
| uyr        | nagpur |
| urr        | nagpur |
| samtanagar | nagpur |
| samtar     | bombay |
| sueje      | bombay |
+------------+--------+
5 rows in set (0.00 sec)

mysql> insert into branch values('sid','dhule');
Query OK, 1 row affected (0.06 sec)


mysql> insert into branch values('shubh','amalner');
Query OK, 1 row affected (0.06 sec)

mysql> insert into branch values('swap','dhule');
Query OK, 1 row affected (0.05 sec)

mysql> select cname from customers where city in ('nagpur','mumbai');
+-------+
| cname |
+-------+
| tct   |
+-------+
1 row in set (0.00 sec)

mysql> select cname from deposit where bname='nagpur' union select cname from customers where city='mumbai';
Empty set (0.00 sec)

mysql> insert into deposit values(10,'pk','nagpur',4656,'2018-07-07');
Query OK, 1 row affected (0.08 sec)

mysql> insert into customers values('pk','mumbai');
Query OK, 1 row affected (0.07 sec)

mysql> select distinct deposit.cname from deposit inner join customers on deposit.cname=customers.cname where deposit.bname='nagpur'and customers.city='mumbai'; 
+-------+
| cname |
+-------+
| pk    |
+-------+
1 row in set (0.00 sec)

mysql> select distinct customers.cname from customers inner join deposit  on customers.city=deposit.bname;
+---------+
| cname   |
+---------+
| shreyas |
| tct     |
+---------+
2 rows in set (0.00 sec)


mysql> select distinct borrow.cname from ((borrow inner join deposit  on borrow.cname=deposit.cname)inner join customers on borrow.cname=customers.cname);
Empty set (0.00 sec)

mysql> select distinct borrow.cname from ((borrow inner join deposit  on borrow.cname=deposit.cname)inner join customers on borrow.cname=customers.cname)where customers.city='nagpur';
Empty set (0.00 sec)

mysql> select * from customers;
+---------+--------+
| cname   | city   |
+---------+--------+
| nitesh  | pune   |
| shreyas | malvan |
| abc     | bombay |
| cdy     | bombay |
| tct     | nagpur |
| pk      | mumbai |
+---------+--------+
6 rows in set (0.00 sec)

mysql> update customers set city='nagpur' where cname='abc';
Query OK, 1 row affected (0.08 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> select distinct borrow.cname from ((borrow inner join deposit  on borrow.cname=deposit.cname)inner join customers on borrow.cname=customers.cname)where customers.city='nagpur';
Empty set (0.00 sec)

