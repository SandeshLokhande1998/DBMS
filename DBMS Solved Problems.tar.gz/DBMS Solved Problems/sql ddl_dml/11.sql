Implement SQL DDL statements which demonstrate the use of SQL objects such as
Table, View, Index, Sequence, Synonym for following relational schema:
Borrower(Rollin, Name, DateofIssue, NameofBook, Status)


show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| SMPS               |
| abd                |
| airplane           |
| d11                |
| emp                |
| mysql              |
| performance_schema |
| sample             |
| sys                |
+--------------------+
10 rows in set (0.14 sec)

mysql> use d11;
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Database changed
mysql> desc department;
+-----------+---------------+------+-----+---------+-------+
| Field     | Type          | Null | Key | Default | Extra |
+-----------+---------------+------+-----+---------+-------+
| dept_name | varchar(20)   | NO   | PRI | NULL    |       |
| building  | varchar(15)   | YES  |     | NULL    |       |
| budget    | decimal(12,2) | YES  |     | NULL    |       |
+-----------+---------------+------+-----+---------+-------+
3 rows in set (0.00 sec)

mysql> alter table department add dept
    -> _no;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '_no' at line 2
mysql> alter table department add dept_no;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
mysql> alter table department add dept_no int;
Query OK, 0 rows affected (0.68 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> update department set dept_no=1 where building="A";
Query OK, 1 row affected (0.09 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> update department set dept_no=2 where building="B";
Query OK, 1 row affected (0.06 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> update department set dept_no=3 where building="C";
Query OK, 1 row affected (0.05 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> select * from department;
+-----------+----------+----------+---------+
| dept_name | building | budget   | dept_no |
+-----------+----------+----------+---------+
| Art       | C        | 17000.00 |       3 |
| Bio       | A        | 12000.00 |       1 |
| Chemistry | B        | 15000.00 |       2 |
| Science   | D        | 18000.00 |    NULL |
+-----------+----------+----------+---------+
4 rows in set (0.00 sec)

mysql> create view dept as select dept_name,dept_no from departmernt;
ERROR 1146 (42S02): Table 'd11.departmernt' doesn't exist
mysql> create view dept as select dept_name,dept_no from department;
Query OK, 0 rows affected (0.07 sec)

mysql> select * from dept;
+-----------+---------+
| dept_name | dept_no |
+-----------+---------+
| Art       |       3 |
| Bio       |       1 |
| Chemistry |       2 |
| Science   |    NULL |
+-----------+---------+
4 rows in set (0.00 sec)

mysql> update dept set dept_name="R"where dept_no=3;
Query OK, 1 row affected (0.25 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> select * from dept;
+-----------+---------+
| dept_name | dept_no |
+-----------+---------+
| Bio       |       1 |
| Chemistry |       2 |
| R         |       3 |
| Science   |    NULL |
+-----------+---------+
4 rows in set (0.00 sec)

mysql> create unique index a1 on department(dept_no,dept_name);
Query OK, 0 rows affected (0.33 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> mysql> 










Employee(EmpNo, Ename ,Designation ,Join date ,Salary , DeptNo, Phone no)

Department(DeptNo, Department, BuildingName)

1)Create database and show all databases
	create database EMP; 
	use EMP; 
2)show databases
	show databases; 

3)Create table and show all table
	create table Employee(EMPNO int(10),ENAME varchar(15),DESIGNATION VARCHAR(15),JOINDATE 		DATE,SAL INT(10),DEPTNO int(10),PHONENO INT(10)); 
	
	create table Department(DEPTNO INT(10),DEPARTMENT VARCHAR(15),BLDGNAME VARCHAR(15)); 
4)SHOW TABLES;      |

5)Show structure of table
 	DESC Employee; 
	 desc Department; 
 
////////////Add 5 records in above table//////////////////

	insert into Employee values(1,"Aryan","Manager","2013-05-22",25000,2,122545789); 
	
	 insert into Employee values(2,"peter","Accountant","2014-06-28",20000,4,1326457809); 
	
	insert into Employee values(3,"Bob","Assistant","2014-02-22",10000,6,1426457509); 
	
	 insert into Employee values(4,"Smith","Secretary","2015-06-10",12000,7,1224575098); 
	
	 insert into Employee values(5,"Charles","Developer","2016-05-10",12056,8,1234775098);
	
	insert into Department values(4,"Management","A1"); 

	insert into Department values(2,"Accounts","B2"); 

 
/////////Department/////////////////

mysql> insert into Department values(2,"Management","A2"); 

mysql> insert into Department values(5,"Production","B1"); 

mysql> insert into Department values(6,"Research","C1"); 


6)Display all records
	select * from Employee; 
7)Display all ‘Accountant’ staff
	select * from Employee where DESIGNATION="Accountant"; 
8)Delete record whose empid is 11
	delete from Employee where EMPNO=11; 
	 select * from Employee; 

9)Delete all records from department table;
	delete from Department; 

10)crease salary of all managers by 100 rupees;
	update Employee set SAL=SAL+100 WHERE DESIGNATION="MANAGER"; 
	select * from Employee; 
11)Add column address
	alter table Employee add column ADDRESS varchar(14); 
	select * from Employee; 
12)Add record for address
	update Employee set ADDRESS="Vadgaon" where EMPNO=1; 
	 update Employee set ADDRESS="Hadapsar" where EMPNO=2; 
	update Employee set ADDRESS="Kondhwa" where EMPNO=3; 
	update Employee set ADDRESS="FcRoad" where EMPNO=4; 
	 select * from Employee; 
13)Drop column building name
	alter table Department drop BLDGNAME; 
 

14)Change the phone number field name to contact number
	alter table Employee change PHONENO CONTACTNO int(10); 
	select * from Employee; 

15)Display employ records in ascending /descending order by their salary
	select * from Employee order by SAL; 
	select * from Employee order by SAL desc; 

16)Delete department table
 	drop table Department; 
17)Delete all records with truncate command.
	truncate table Employee;

