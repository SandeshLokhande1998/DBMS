Design at least 10 SQL queries for suitable database application using SQL DML
statements: all types of Join, Sub-Query and View.





mysql> create database join1;
Query OK, 1 row affected (0.00 sec)

mysql> use join1;
Database changed

mysql> show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| SMPS               |
| abd                |
| airplane           |
| d11                |
| emp                |
| join1              |
| mysql              |
| performance_schema |
| sample             |
| sys                |
+--------------------+
11 rows in set (0.00 sec)

mysql> create table branch(branch_id int primary key,branch_name varchar(20));
Query OK, 0 rows affected (0.28 sec)

/////
2. List the employee details along with branch name using the inner join and in the order of emp_no.

select emp_no,emp_name,branch_name from emp e inner join branch b on e.branch_id=b.branch_id order by emp_no;
+--------+----------+--------------+
| emp_no | emp_name | branch_name  |
+--------+----------+--------------+
|     10 | Aryan    | parkstreet   |
|     11 | Kiran    | Pimpri       |
|     12 | Carol    | vadgaon      |
|     13 | Peter    | Panvel       |
|     14 | Bob      | Model Colony |
+--------+----------+--------------+
5 rows in set (0.00 sec)





mysql> create table branch(branch_id int primary key auto_increment,branch_name varchar(20));
Query OK, 0 rows affected (0.36 sec)

mysql> insert into branch values(1,"vadgaon");
Query OK, 1 row affected (0.07 sec)

mysql> insert into branch values(2,"parkstreet");
Query OK, 1 row affected (0.05 sec)

mysql> insert into branch values(2,"Panvel");
ERROR 1062 (23000): Duplicate entry '2' for key 'PRIMARY'
mysql> insert into branch values(3,"Panvel");
Query OK, 1 row affected (0.06 sec)

mysql> insert into branch values(4,"Pimpri");
Query OK, 1 row affected (0.06 sec)

mysql> insert into branch values(5,"Model Colony");
Query OK, 1 row affected (0.07 sec)



mysql> ALTER TABLE emp ADD FOREIGN KEY fk(branch_id)REFERENCES branch(branch_id);
Query OK, 0 rows affected (0.92 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> insert into emp values(10,"Aryan",2,40000,"Manager",101);
Query OK, 1 row affected (0.06 sec)

mysql> insert into emp values(11,"Kiran",4,5000,"Admin",102);
Query OK, 1 row affected (0.05 sec)

mysql> insert into emp values(12,"Carol",1,6000,"Assistant",103);
Query OK, 1 row affected (0.06 sec)

mysql> insert into emp values(13,"Peter",3,12000,"Senior",104);
Query OK, 1 row affected (0.05 sec)

mysql> insert into emp values(14,"Bob",5,11000,"HR",105);
Query OK, 1 row affected (0.06 sec)



mysql> create table contact_details(emp_id int not null ,email_id varchar(20),phone_no int(10) not null  );
Query OK, 0 rows affected (0.38 sec)


mysql> ALTER TABLE contact_details  ADD Primary key(emp_id);
Query OK, 0 rows affected (0.41 sec)
Records: 0  Duplicates: 0  Warnings: 0



mysql> insert into contact_details values(11,"Kiran@gamil.com",989015476);
Query OK, 1 row affected (0.05 sec)

mysql> insert into contact_details values(10,"Aryan@gamil.com",889015476);
Query OK, 1 row affected (0.06 sec)

mysql> insert into contact_details values(13,"Peter@gamil.com",789015476);
Query OK, 1 row affected (0.06 sec)


mysql> create table emp_details(emp_id int not null,street varchar(20),city varchar(20),state varchar(20));
Query OK, 0 rows affected (0.28 sec)



mysql> insert into emp_details values(10,"Vadgaon","Pune ","Maharashtra");
Query OK, 1 row affected (0.07 sec)

mysql> insert into emp_details values(11,"Link Road","Mumbai ","Maharashtra");
Query OK, 1 row affected (0.05 sec)

mysql> insert into emp_details values(12,"parkstreet","Kolkata ","West Bangal");
Query OK, 1 row affected (0.07 sec)

mysql> insert into emp_details values(13,"Roha","Banglore ","Karnatka");
Query OK, 1 row affected (0.05 sec)

mysql> insert into emp_details values(14,"Street Ora","cuttak ","Orissa");
Query OK, 1 row affected (0.05 sec)

mysql> create table branch_address(branch_id int not null,city varchar(20),state varchar(20));
Query OK, 0 rows affected (0.25 sec)

mysql> ALTER TABLE branch_address ADD FOREIGN KEY fk2(branch_id)REFERENCES branch(branch_id);
Query OK, 0 rows affected (0.82 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> insert into branch_address values(1,"Pune","Maharashtra");
Query OK, 1 row affected (0.06 sec)

mysql> insert into branch_address values(2,"Kolkata","West Bangal");
Query OK, 1 row affected (0.06 sec)

mysql> insert into branch_address values(3,"Mumbai","Maharahtra");
Query OK, 1 row affected (0.05 sec)

mysql> insert into branch_address values(5,"Banglore","Karnataka");
Query OK, 1 row affected (0.08 sec)

mysql> insert into branch_address values(4,"cuttak","Orissa");
Query OK, 1 row affected (0.05 sec)

mysql> select * from branch;
+-----------+--------------+
| branch_id | branch_name  |
+-----------+--------------+
|         1 | vadgaon      |
|         2 | parkstreet   |
|         3 | Panvel       |
|         4 | Pimpri       |
|         5 | Model Colony |
+-----------+--------------+
5 rows in set (0.00 sec)

mysql> select * from emp;
+--------+----------+-----------+--------+-----------+------------+
| emp_no | emp_name | branch_id | salary | Dept      | manager_id |
+--------+----------+-----------+--------+-----------+------------+
|     10 | Aryan    |         2 |  40000 | Manager   | 101        |
|     11 | Kiran    |         4 |   5000 | Admin     | 102        |
|     12 | Carol    |         1 |   6000 | Assistant | 103        |
|     13 | Peter    |         3 |  12000 | Senior    | 104        |
|     14 | Bob      |         5 |  11000 | HR        | 105        |
+--------+----------+-----------+--------+-----------+------------+
5 rows in set (0.00 sec)

mysql> select * from contact_details;
+--------+-----------------+-----------+
| emp_id | email_id        | phone_no  |
+--------+-----------------+-----------+
|     10 | Aryan@gamil.com | 889015476 |
|     11 | Kiran@gamil.com | 989015476 |
|     13 | Peter@gamil.com | 789015476 |
+--------+-----------------+-----------+
3 rows in set (0.01 sec)

mysql> select * from emp_details;
+--------+------------+-----------+-------------+
| emp_id | street     | city      | state       |
+--------+------------+-----------+-------------+
|     10 | Vadgaon    | Pune      | Maharashtra |
|     11 | Link Road  | Mumbai    | Maharashtra |
|     12 | parkstreet | Kolkata   | West Bangal |
|     13 | Roha       | Banglore  | Karnatka    |
|     14 | Street Ora | cuttak    | Orissa      |
+--------+------------+-----------+-------------+
5 rows in set (0.00 sec)

mysql> select * from branch_address;
+-----------+----------+-------------+
| branch_id | city     | state       |
+-----------+----------+-------------+
|         1 | Pune     | Maharashtra |
|         2 | Kolkata  | West Bangal |
|         3 | Mumbai   | Maharahtra  |
|         5 | Banglore | Karnataka   |
|         4 | cuttak   | Orissa      |
+-----------+----------+-------------+
5 rows in set (0.00 sec)


//////
3. List the details of employee who belong to admin department along with the branch name to which they belong.

select emp_name,dept,branch_name from branch b,emp e where b.branch_id=e.branch_id and dept="Admin"; 
+----------+-------+-------------+
| emp_name | dept  | branch_name |
+----------+-------+-------------+
| Kiran    | Admin | Pimpri      |
+----------+-------+-------------+
1 row in set (0.01 sec)

////////
4. List the employee name along with the phone no and city using inner join.


 select emp_name,phone_no,city from emp e inner join emp_details a on e.emp_no=a.emp_id inner join contact_details c on e.emp_no=c.emp_id;
+----------+-----------+-----------+
| emp_name | phone_no  | city      |
+----------+-----------+-----------+
| Aryan    | 889015476 | Pune      |
| Kiran    | 989015476 | Mumbai    |
| Peter    | 789015476 | Banglore  |
+----------+-----------+-----------+




//////
5. List the employee name with the contact details (if any).

 select emp_name,email_id,phone_no from emp e left join contact_details c on e.emp_no=c.emp_id;
+----------+-----------------+-----------+
| emp_name | email_id        | phone_no  |
+----------+-----------------+-----------+
| Aryan    | Aryan@gamil.com | 889015476 |
| Kiran    | Kiran@gamil.com | 989015476 |
| Peter    | Peter@gamil.com | 789015476 |
| Carol    | NULL            |      NULL |
| Bob      | NULL            |      NULL |
+----------+-----------------+-----------+
5 rows in set (0.00 sec)

3 rows in set (0.00 sec)

/////////
6. List the employee contact details irrespective of whether they are working or have left.

mysql>  delete from emp where emp_no=12;
Query OK, 1 row affected (0.07 sec)

mysql>  delete from emp where emp_no=13;
Query OK, 1 row affected (0.06 sec)

mysql> select * from emp;
+--------+----------+-----------+--------+---------+------------+
| emp_no | emp_name | branch_id | salary | Dept    | manager_id |
+--------+----------+-----------+--------+---------+------------+
|     10 | Aryan    |         2 |  40000 | Manager | 101        |
|     11 | Kiran    |         4 |   5000 | Admin   | 102        |
|     14 | Bob      |         5 |  11000 | HR      | 105        |
+--------+----------+-----------+--------+---------+------------+
3 rows in set (0.00 sec)

mysql> select emp_name,email_id,phone_no from emp e right join contact_details c on e.emp_no=c.emp_id; 
+----------+-----------------+-----------+
| emp_name | email_id        | phone_no  |
+----------+-----------------+-----------+
| Aryan    | Aryan@gamil.com | 889015476 |
| Kiran    | Kiran@gamil.com | 989015476 |
| NULL     | Peter@gamil.com | 789015476 |
+----------+-----------------+-----------+
3 rows in set (0.00 sec)


/////
7. Retrieve the employee name and their respective manager name.

     select e1.emp_name,e2.emp_name as Manager from Empmaster e1,Empmaster e2 where e1.manager_id=e2.emp_id; 
Empty set (0.00 sec)
////
8. List the employee details along with branch name using natural join

select emp_name,dept,branch_name,salary from branch b natural join emp e;
+----------+---------+--------------+--------+
| emp_name | dept    | branch_name  | salary |
+----------+---------+--------------+--------+
| Aryan    | Manager | parkstreet   |  40000 |
| Kiran    | Admin   | Pimpri       |   5000 |
| Bob      | HR      | Model Colony |  11000 |
+----------+---------+--------------+--------+
3 rows in set (0.00 sec)

/////////
9. List the employee names who work at the vadgaon branch along with the city of that employee.

select e.emp_no,emp_name,city from emp e,branch b,emp_details a where b.branch_name="Vadgaon" and b.branch_id=e.branch_id and e.emp_no=a.emp_id; 
Empty set (0.00 sec)


/////////
10. Find the employee who works at the vadgaon branch with salary>10000 and list the employee names with streets and city they live in.

select emp_name,street,city,salary from emp e,emp_details a where e.emp_no=a.emp_id and e.emp_no in(select emp_id from branch b,emp c where branch_name="Vadgaon" and salary>10000 and b.branch_id=c.branch_id); 
Empty set (0.00 sec)
/////

11. Find the employees who live and work in same city.

select emp_name from emp e,branch b,emp_details a,branch_address c where e.emp_no=a.emp_id and b.branch_id=e.branch_id and c.branch_id=b.branch_id and c.city=a.city;
Empty set (0.00 sec)


//////subquery example

12. Find the employees whose salaries are more than everybody who works at branch vadgaon.

select emp_name from emp where salary>all(select salary from emp e,branch b where e.branch_id=b.branch_id and branch_name="Vadgaon");  +----------+
| emp_name |
+----------+
| Aryan    |
| Kiran    |
| Bob      |
+----------+
3 rows in set (0.00 sec)


/////////

13. Create a view which will contain total employees at each branch.

create view TotEmp as select branch_name,count(emp_no) as TotalEmployees from emp e,branch b where e.branch_id=b.branch_id group by e.branch_id;
Query OK, 0 rows affected (0.05 sec)

mysql> select * from TotEmp;
+--------------+----------------+
| branch_name  | TotalEmployees |
+--------------+----------------+
| parkstreet   |              1 |
| Pimpri       |              1 |
| Model Colony |              1 |
+--------------+----------------+
3 rows in set (0.00 sec)

////////

14. List the branch names where employee have a salary>10000.

select branch_name from emp e,branch b where e.branch_id=b.branch_id and salary>10000;
+--------------+
| branch_name  |
+--------------+
| parkstreet   |
| Model Colony |
+--------------+
2 rows in set (0.00 sec)


///////
15. Create a view which will show the avg salary and the total salary at each branch.

 create view Emp1 as select branch_name,avg(salary),sum(salary) from emp e,branch b where e.branch_id=b.branch_id group by e.branch_id; 
Query OK, 0 rows affected (0.06 sec)

mysql> select * from Emp1;
+--------------+-------------+-------------+
| branch_name  | avg(salary) | sum(salary) |
+--------------+-------------+-------------+
| parkstreet   |  40000.0000 |       40000 |
| Pimpri       |   5000.0000 |        5000 |
| Model Colony |  11000.0000 |       11000 |
+--------------+-------------+-------------+
3 rows in set (0.00 sec)

///////////

16. Find the employee who do not have a job at vadgaon branch.

select emp_name from emp e,branch b where e.branch_id=b.branch_id and e.branch_id not in(select branch_id from branch where branch_name="vadgaon"); 
+----------+
| emp_name |
+----------+
| Aryan    |
| Kiran    |
| Bob      |
+----------+
3 rows in set (0.00 sec)








 
