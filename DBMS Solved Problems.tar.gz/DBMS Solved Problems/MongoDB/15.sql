
Implement Indexing and querying with MongoDB using following example.

Students(stud_id, stud_name,stud_addr,stud_marks)







narayani@Narayani:~$ sudo systemctl enable mongod
[sudo] password for narayani: 
narayani@Narayani:~$ mongo




> use d15;
switched to db d15

> db.createCollection('student');
{ "ok" : 1 }
> show collections;
student


> db.student.insert({stude_id:1,stud_name:'Neha',stud_addr:'pune',stud_marks:70});
WriteResult({ "nInserted" : 1 })
> db.student.insert({stude_id:2,stud_name:'Divya',stud_addr:'pune',stud_marks:80});
WriteResult({ "nInserted" : 1 })
> db.student.insert({stude_id:3,stud_name:'Rakesh',stud_addr:'pune',stud_marks:90});
WriteResult({ "nInserted" : 1 })
> db.student.find().pretty();
{
	"_id" : ObjectId("5bd0bf58740e663c1ef92623"),
	"stude_id" : 1,
	"stud_name" : "Neha",
	"stud_addr" : "pune",
	"stud_marks" : 70
}
{
	"_id" : ObjectId("5bd0bf77740e663c1ef92624"),
	"stude_id" : 2,
	"stud_name" : "Divya",
	"stud_addr" : "pune",
	"stud_marks" : 80
}
{
	"_id" : ObjectId("5bd0bfa5740e663c1ef92625"),
	"stude_id" : 3,
	"stud_name" : "Rakesh",
	"stud_addr" : "pune",
	"stud_marks" : 90
}




> db.student.ensureIndex({"stud_id":1})   ////create  ascending order index on the id field
{
	"createdCollectionAutomatically" : false,
	"numIndexesBefore" : 1,
	"numIndexesAfter" : 2,
	"ok" : 1
}



> db.student.find().pretty();
{
	"_id" : ObjectId("5bd0bf58740e663c1ef92623"),
	"stude_id" : 1,
	"stud_name" : "Neha",
	"stud_addr" : "pune",
	"stud_marks" : 70
}
{
	"_id" : ObjectId("5bd0bf77740e663c1ef92624"),
	"stude_id" : 2,
	"stud_name" : "Divya",
	"stud_addr" : "pune",
	"stud_marks" : 80
}
{
	"_id" : ObjectId("5bd0bfa5740e663c1ef92625"),
	"stude_id" : 3,
	"stud_name" : "Rakesh",
	"stud_addr" : "pune",
	"stud_marks" : 90
}





> db.student.ensureIndex({"stud_id":1,"stud_name":-1});    ////create  ascending order index on 								the id field and descending order 										index on name field
{
	"createdCollectionAutomatically" : false,
	"numIndexesBefore" : 2,
	"numIndexesAfter" : 3,
	"ok" : 1
}
> db.student.find().pretty();
{
	"_id" : ObjectId("5bd0bf58740e663c1ef92623"),
	"stude_id" : 1,
	"stud_name" : "Neha",
	"stud_addr" : "pune",
	"stud_marks" : 70
}
{
	"_id" : ObjectId("5bd0bf77740e663c1ef92624"),
	"stude_id" : 2,
	"stud_name" : "Divya",
	"stud_addr" : "pune",
	"stud_marks" : 80
}
{
	"_id" : ObjectId("5bd0bfa5740e663c1ef92625"),
	"stude_id" : 3,
	"stud_name" : "Rakesh",
	"stud_addr" : "pune",
	"stud_marks" : 90
}
> 

