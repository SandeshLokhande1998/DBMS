17: Implement all Aggregation operations and types of indexing with following collection using MongoDB. 
Employee(emp_id, emp_name,emp_dept,salary)


> use d17;
switched to db d17



> db.emp.insert({'emp_id':1,'emp_name':'vedant','emp_dept':'comp','salary':40000});
WriteResult({ "nInserted" : 1 })

> db.emp.insert({'emp_id':2,'emp_name':'dant','emp_dept':'comp','salary':20000});
WriteResult({ "nInserted" : 1 })

> db.emp.insert({'emp_id':3,'emp_name':'Prakash','emp_dept':'it','salary':20000});
WriteResult({ "nInserted" : 1 })

> db.emp.insert({'emp_id':4,'emp_name':'anil','emp_dept':'it','salary':30000});
WriteResult({ "nInserted" : 1 })

> db.emp.aggregate([{$group:{_id:"$emp_name",avg_sal_in_dept:{$avg:"$salary"}}}])
{ "_id" : "Prakash", "avg_sal_in_dept" : 20000 }
{ "_id" : "anil", "avg_sal_in_dept" : 30000 }
{ "_id" : "dant", "avg_sal_in_dept" : 20000 }
{ "_id" : "vedant", "avg_sal_in_dept" : 40000 }

> db.emp.aggregate([{$group:{_id:"$emp_dept",avg_sal_in_dept:{$avg:"$salary"}}}])
{ "_id" : "it", "avg_sal_in_dept" : 25000 }
{ "_id" : "comp", "avg_sal_in_dept" : 30000 }

> db.emp.aggregate([{$group:{_id:"$emp_dept",total_sal_in_dept:{$sum:"$salary"}}}])
{ "_id" : "it", "total_sal_in_dept" : 50000 }
{ "_id" : "comp", "total_sal_in_dept" : 60000 }

> db.emp.aggregate([{$group:{_id:"$emp_dept",min_sal_in_dept:{$min:"$salary"}}}])
{ "_id" : "it", "min_sal_in_dept" : 20000 }
{ "_id" : "comp", "min_sal_in_dept" : 20000 }

> db.emp.aggregate([{$group:{_id:"$emp_dept",max_sal_in_dept:{$max:"$salary"}}}])
{ "_id" : "it", "max_sal_in_dept" : 30000 }
{ "_id" : "comp", "max_sal_in_dept" : 40000 }

> db.emp.aggregate([{$group:{_id:"$emp_dept",count_sal_in_dept:{$sum:1}}}])
{ "_id" : "it", "count_sal_in_dept" : 2 }
{ "_id" : "comp", "count_sal_in_dept" : 2 }

> db.emp.aggregate([{$group:{_id:"$emp_dept",count_sal_in_dept:{$sum:"$salary"}}}])
{ "_id" : "it", "count_sal_in_dept" : 50000 }
{ "_id" : "comp", "count_sal_in_dept" : 60000 }

> db.emp.aggregate([{$group:{_id:"$emp_dept",last_sal_in_dept:{$last:"$salary"}}}])
{ "_id" : "it", "last_sal_in_dept" : 30000 }
{ "_id" : "comp", "last_sal_in_dept" : 20000 }

> db.emp.aggregate([{$group:{_id:"$emp_dept",first_sal_in_dept:{$first:"$salary"}}}])
{ "_id" : "it", "first_sal_in_dept" : 20000 }
{ "_id" : "comp", "first_sal_in_dept" : 40000 }


>  db.emp.find().pretty()
{
	"_id" : ObjectId("5bd0eb676cf652766665b137"),
	"emp_id" : 1,
	"emp_name" : "vedant",
	"emp_dept" : "comp",
	"salary" : 40000
}
{
	"_id" : ObjectId("5bd0eb806cf652766665b138"),
	"emp_id" : 2,
	"emp_name" : "dant",
	"emp_dept" : "comp",
	"salary" : 20000
}
{
	"_id" : ObjectId("5bd0ebb06cf652766665b139"),
	"emp_id" : 3,
	"emp_name" : "Prakash",
	"emp_dept" : "it",
	"salary" : 20000
}
{
	"_id" : ObjectId("5bd0ebc56cf652766665b13a"),
	"emp_id" : 4,
	"emp_name" : "anil",
	"emp_dept" : "it",
	"salary" : 30000
}
> db.emp.ensureIndex({"emp_id":1})
{
	"createdCollectionAutomatically" : false,
	"numIndexesBefore" : 1,
	"numIndexesAfter" : 2,
	"ok" : 1
}
> db.emp.find().pretty()
{
	"_id" : ObjectId("5bd0eb676cf652766665b137"),
	"emp_id" : 1,
	"emp_name" : "vedant",
	"emp_dept" : "comp",
	"salary" : 40000
}
{
	"_id" : ObjectId("5bd0eb806cf652766665b138"),
	"emp_id" : 2,
	"emp_name" : "dant",
	"emp_dept" : "comp",
	"salary" : 20000
}
{
	"_id" : ObjectId("5bd0ebb06cf652766665b139"),
	"emp_id" : 3,
	"emp_name" : "Prakash",
	"emp_dept" : "it",
	"salary" : 20000
}
{
	"_id" : ObjectId("5bd0ebc56cf652766665b13a"),
	"emp_id" : 4,
	"emp_name" : "anil",
	"emp_dept" : "it",
	"salary" : 30000
}
> db.emp.ensureIndex({"emp_id":1,"emp_name":-1});
{
	"createdCollectionAutomatically" : false,
	"numIndexesBefore" : 2,
	"numIndexesAfter" : 3,
	"ok" : 1
}
> db.emp.find().pretty()
{
	"_id" : ObjectId("5bd0eb676cf652766665b137"),
	"emp_id" : 1,
	"emp_name" : "vedant",
	"emp_dept" : "comp",
	"salary" : 40000
}
{
	"_id" : ObjectId("5bd0eb806cf652766665b138"),
	"emp_id" : 2,
	"emp_name" : "dant",
	"emp_dept" : "comp",
	"salary" : 20000
}
{
	"_id" : ObjectId("5bd0ebb06cf652766665b139"),
	"emp_id" : 3,
	"emp_name" : "Prakash",
	"emp_dept" : "it",
	"salary" : 20000
}
{
	"_id" : ObjectId("5bd0ebc56cf652766665b13a"),
	"emp_id" : 4,
	"emp_name" : "anil",
	"emp_dept" : "it",
	"salary" : 30000
}

