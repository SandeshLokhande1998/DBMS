
8a.Create a collection sites(url,dateofaccess). Write a MapReduce function to find the no. of times a site was accessed in a month.




> use d8;
switched to db d8


> db.sites.insert([ {'url':'www.google.com','date_of_access':'2018-07-07'},
... {'url':'www.google.com','date_of_access':'2017-07-08'},
... {'url':'www.facebook.com','date_of_access':'2018-07-06'},
... {'url':'www.facebook.com','date_of_access':'2018-07-06'}]);
BulkWriteResult({
	"writeErrors" : [ ],
	"writeConcernErrors" : [ ],
	"nInserted" : 4,
	"nUpserted" : 0,
	"nMatched" : 0,
	"nModified" : 0,
	"nRemoved" : 0,
	"upserted" : [ ]
})
> db.sites.find().pretty();
{
	"_id" : ObjectId("5bd0e34de4487747fde88912"),
	"url" : "www.google.com",
	"date_of_access" : "2018-07-07"
}
{
	"_id" : ObjectId("5bd0e34de4487747fde88913"),
	"url" : "www.google.com",
	"date_of_access" : "2017-07-08"
}
{
	"_id" : ObjectId("5bd0e34de4487747fde88914"),
	"url" : "www.facebook.com",
	"date_of_access" : "2018-07-06"
}
{
	"_id" : ObjectId("5bd0e34de4487747fde88915"),
	"url" : "www.facebook.com",
	"date_of_access" : "2018-07-06"
}





> db.sites.mapReduce( function(){emit(this.url,1);},
... function(key,values){return Array.sum(values)},
... {
... query:{url:"www.google.com"},
... out:"access_time"
... }
... )
{
	"result" : "access_time",
	"timeMillis" : 836,
	"counts" : {
		"input" : 2,
		"emit" : 2,
		"reduce" : 1,
		"output" : 1
	},
	"ok" : 1
}
> db.access_time.find();
{ "_id" : "www.google.com", "value" : "2018-07-072017-07-08" }






> db.sites.mapReduce( function(){emit(this.url,this.date_of_access);}, function(key,values){return Array.sum(values)}, { query:{url:"www.google.com"}, out:"access_time" },{query:{url:"www.facebook.com"},out:"access_time_1"} )
{
	"result" : "access_time",
	"timeMillis" : 560,
	"counts" : {
		"input" : 2,
		"emit" : 2,
		"reduce" : 1,
		"output" : 1
	},
	"ok" : 1
}
> db.access_time.find();
{ "_id" : "www.google.com", "value" : "2018-07-072017-07-08" }
> db.access_time_1.find();




















8b. Implement all Aggregation operations on following collection using MongoDB. 
Employee(emp_id, emp_name,emp_dept,salary)



> use d8;
switched to db d8
> db.emp.insert({'emp_id':1,'emp_name':'Arpit','emp_dept':'12','salary':12000});

WriteResult({ "nInserted" : 1 })

> db.emp.insert({'emp_id':2,'emp_name':'Arvind','emp_dept':'12','salary':13000});
WriteResult({ "nInserted" : 1 })

> db.emp.insert({'emp_id':3,'emp_name':'Avinash','emp_dept':'13','salary':14000});
WriteResult({ "nInserted" : 1 })

> db.emp.insert({'emp_id':4,'emp_name':'sunny','emp_dept':'13','salary':15000});

WriteResult({ "nInserted" : 1 })
> db.emp.insert({'emp_id':5,'emp_name':'yaku','emp_dept':'13','salary':14000});
WriteResult({ "nInserted" : 1 })

> db.emp.find().pretty();

{
	"_id" : ObjectId("5bd0c79f1cdd8db08f52644a"),
	"emp_id" : 1,
	"emp_name" : "Arpit",
	"emp_dept" : "12",
	"salary" : 12000
}
{
	"_id" : ObjectId("5bd0c7c81cdd8db08f52644b"),
	"emp_id" : 2,
	"emp_name" : "Arvind",
	"emp_dept" : "12",
	"salary" : 13000
}
{
	"_id" : ObjectId("5bd0c7e71cdd8db08f52644c"),
	"emp_id" : 3,
	"emp_name" : "Avinash",
	"emp_dept" : "13",
	"salary" : 14000
}
{
	"_id" : ObjectId("5bd0c86d1cdd8db08f52644d"),
	"emp_id" : 4,
	"emp_name" : "sunny",
	"emp_dept" : "13",
	"salary" : 15000
}
{
	"_id" : ObjectId("5bd0caad1cdd8db08f52644e"),
	"emp_id" : 5,
	"emp_name" : "yaku",
	"emp_dept" : "13",
	"salary" : 14000
}



> db.emp.aggregate([{$group:{_id:"$emp_name",avg_sal_in_dept:{$avg:"$salary"}}}])
{ "_id" : "yaku", "avg_sal_in_dept" : 14000 }
{ "_id" : "Arvind", "avg_sal_in_dept" : 13000 }
{ "_id" : "Arpit", "avg_sal_in_dept" : 12000 }
{ "_id" : "Avinash", "avg_sal_in_dept" : 14000 }
{ "_id" : "sunny", "avg_sal_in_dept" : 15000 }



> db.emp.aggregate([{$group:{_id:"$emp_dept",avg_sal_in_dept:{$avg:"$salary"}}}])
{ "_id" : "13", "avg_sal_in_dept" : 14333.333333333334 }
{ "_id" : "12", "avg_sal_in_dept" : 12500 }



> db.emp.aggregate([{$group:{_id:"$emp_dept",total_sal_in_dept:{$sum:"$salary"}}}])
{ "_id" : "13", "total_sal_in_dept" : 43000 }
{ "_id" : "12", "total_sal_in_dept" : 25000 }



> db.emp.aggregate([{$group:{_id:"$emp_dept",min_sal_in_dept:{$min:"$salary"}}}])
{ "_id" : "13", "min_sal_in_dept" : 14000 }
{ "_id" : "12", "min_sal_in_dept" : 12000 }


> db.emp.aggregate([{$group:{_id:"$emp_dept",max_sal_in_dept:{$max:"$salary"}}}])
{ "_id" : "13", "max_sal_in_dept" : 15000 }
{ "_id" : "12", "max_sal_in_dept" : 13000 }


> db.emp.aggregate([{$group:{_id:"$emp_dept",count_sal_in_dept:{$sum:1}}}])
{ "_id" : "13", "count_sal_in_dept" : 3 }
{ "_id" : "12", "count_sal_in_dept" : 2 }



> db.emp.aggregate([{$group:{_id:"$emp_dept",count_sal_in_dept:{$sum:"$salary"}}}])
{ "_id" : "13", "count_sal_in_dept" : 43000 }
{ "_id" : "12", "count_sal_in_dept" : 25000 }


> db.emp.aggregate([{$group:{_id:"$emp_dept",last_sal_in_dept:{$last:"$salary"}}}])
{ "_id" : "13", "last_sal_in_dept" : 14000 }
{ "_id" : "12", "last_sal_in_dept" : 13000 }

> db.emp.aggregate([{$group:{_id:"$emp_dept",first_sal_in_dept:{$first:"$salary"}}}])
{ "_id" : "13", "first_sal_in_dept" : 14000 }
{ "_id" : "12", "first_sal_in_dept" : 12000 }

> db.emp.find()
{ "_id" : ObjectId("5bd0c79f1cdd8db08f52644a"), "emp_id" : 1, "emp_name" : "Arpit", "emp_dept" : "12", "salary" : 12000 }
{ "_id" : ObjectId("5bd0c7c81cdd8db08f52644b"), "emp_id" : 2, "emp_name" : "Arvind", "emp_dept" : "12", "salary" : 13000 }
{ "_id" : ObjectId("5bd0c7e71cdd8db08f52644c"), "emp_id" : 3, "emp_name" : "Avinash", "emp_dept" : "13", "salary" : 14000 }
{ "_id" : ObjectId("5bd0c86d1cdd8db08f52644d"), "emp_id" : 4, "emp_name" : "sunny", "emp_dept" : "13", "salary" : 15000 }
{ "_id" : ObjectId("5bd0caad1cdd8db08f52644e"), "emp_id" : 5, "emp_name" : "yaku", "emp_dept" : "13", "salary" : 14000 }
> 

