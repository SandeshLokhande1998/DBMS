22. Create  following collection and  using MongoDB  implement all CRUD operations.
Orders(cust_id, amount, status)



> use d22;
switched to db d22

> db.createCollection('orders');
{ "ok" : 1 }


> db.orders.insert( [{'cust_id':1,'amount':500,'status':'A'}, {'cust_id':2,'amount':800,'status':'B'}, {'cust_id':3,'amount':1000,'status':'NA'}, {'cust_id':4,'amount':200,'status':'A'}, {'cust_id':5,'amount':800,'status':'NA'}] )
BulkWriteResult({
	"writeErrors" : [ ],
	"writeConcernErrors" : [ ],
	"nInserted" : 5,
	"nUpserted" : 0,
	"nMatched" : 0,
	"nModified" : 0,
	"nRemoved" : 0,
	"upserted" : [ ]
})


> db.orders.find().pretty();
{
	"_id" : ObjectId("5bd0fa06303d5d1398d4743c"),
	"cust_id" : 1,
	"amount" : 500,
	"status" : "A"
}
{
	"_id" : ObjectId("5bd0fa06303d5d1398d4743d"),
	"cust_id" : 2,
	"amount" : 800,
	"status" : "B"
}
{
	"_id" : ObjectId("5bd0fa06303d5d1398d4743e"),
	"cust_id" : 3,
	"amount" : 1000,
	"status" : "NA"
}
{
	"_id" : ObjectId("5bd0fa06303d5d1398d4743f"),
	"cust_id" : 4,
	"amount" : 200,
	"status" : "A"
}
{
	"_id" : ObjectId("5bd0fa06303d5d1398d47440"),
	"cust_id" : 5,
	"amount" : 800,
	"status" : "NA"
}



> db.orders.update({'cust_id':2},{$set:{'amount':1500}});
WriteResult({ "nMatched" : 1, "nUpserted" : 0, "nModified" : 1 })

> db.orders.find().pretty();
{
	"_id" : ObjectId("5bd0fa06303d5d1398d4743c"),
	"cust_id" : 1,
	"amount" : 500,
	"status" : "A"
}
{
	"_id" : ObjectId("5bd0fa06303d5d1398d4743d"),
	"cust_id" : 2,
	"amount" : 1500,
	"status" : "B"
}
{
	"_id" : ObjectId("5bd0fa06303d5d1398d4743e"),
	"cust_id" : 3,
	"amount" : 1000,
	"status" : "NA"
}
{
	"_id" : ObjectId("5bd0fa06303d5d1398d4743f"),
	"cust_id" : 4,
	"amount" : 200,
	"status" : "A"
}
{
	"_id" : ObjectId("5bd0fa06303d5d1398d47440"),
	"cust_id" : 5,
	"amount" : 800,
	"status" : "NA"
}




> db.orders.remove({'cust_id':2});
WriteResult({ "nRemoved" : 1 })

> db.orders.find().pretty();
{
	"_id" : ObjectId("5bd0fa06303d5d1398d4743c"),
	"cust_id" : 1,
	"amount" : 500,
	"status" : "A"
}
{
	"_id" : ObjectId("5bd0fa06303d5d1398d4743e"),
	"cust_id" : 3,
	"amount" : 1000,
	"status" : "NA"
}
{
	"_id" : ObjectId("5bd0fa06303d5d1398d4743f"),
	"cust_id" : 4,
	"amount" : 200,
	"status" : "A"
}
{
	"_id" : ObjectId("5bd0fa06303d5d1398d47440"),
	"cust_id" : 5,
	"amount" : 800,
	"status" : "NA"
}

