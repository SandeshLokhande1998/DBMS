write a trigger for Library (bid, bname, doi, status) to update the number of copies (noc) according to ISSUE & RETURN status on update or insert query. Increase the noc if status is RETURN, Decrease noc if status is ISSUE in Library_Audit table(bid,bname,noc,timestamp of query,FINE).Write a trigger after update on Library such that if doi is more than 20 days ago then status should be FINE and in the Library_Audit table fine should be equal to no. of days * 10







create trigger after_insert_lib
     AFTER INSERT
    ON lib
     FOR EACH ROW
    begin
     if (new.status LIKE 'issue') then
     insert into library_audit values(new.bid,new.bname,0,current_timestamp);
     else
     insert into library_audit values(new.bid,new.bname,1,current_timestamp);
     end if;
     end; //






create trigger after_update_library
 AFTER UPDATE
 ON lib
 FOR EACH ROW
 begin
 if (new.status LIKE 'issue') then
 insert into library_audit values(new.bid,new.bname,0,current_timestamp);
 else
 insert into library_audit values(new.bid,new.bname,1,current_timestamp);
 end if;
 end; //





mysql> create database trig;
Query OK, 1 row affected (0.00 sec)

mysql> use trig;
Database changed

mysql> create table lib(bid int,bname varchar(20),doi date,status varchar(20));
Query OK, 0 rows affected (0.21 sec)






mysql> create trigger after_insert_lib                                            
    ->      AFTER INSERT
    ->     ON lib
    ->      FOR EACH ROW
    ->     begin
    ->      if (new.status LIKE 'issue') then
    ->      insert into library_audit values(new.bid,new.bname,0,current_timestamp);
    ->      else
    ->      insert into library_audit values(new.bid,new.bname,1,current_timestamp);
    ->      end if;
    ->      end; //
Query OK, 0 rows affected (0.12 sec)




mysql> create table library_audit(bid int,bname varchar(20),noc int,timestamp_of_query date);
Query OK, 0 rows affected (0.23 sec)

mysql> insert into lib values(1,'cn','2018-08-08','issue');
    
Query OK, 1 row affected (0.05 sec)

mysql> select * from lib;
    

+------+-------+------------+--------+
| bid  | bname | doi        | status |
+------+-------+------------+--------+
|    1 | cn    | 2018-08-08 | issue  |
+------+-------+------------+--------+
1 row in set (0.00 sec)

mysql> select * from library_audit;
    

+------+-------+------+--------------------+
| bid  | bname | noc  | timestamp_of_query |
+------+-------+------+--------------------+
|    1 | cn    |    0 | 2018-10-24         |
+------+-------+------+--------------------+
1 row in set (0.00 sec)




mysql> create trigger after_update_library
    ->  AFTER UPDATE
    ->  ON lib
    ->  FOR EACH ROW
    ->  begin
    ->  if (new.status LIKE 'issue') then
    ->  insert into library_audit values(new.bid,new.bname,0,current_timestamp);
    ->  else
    ->  insert into library_audit values(new.bid,new.bname,1,current_timestamp);
    ->  end if;
    ->  end; //
Query OK, 0 rows affected (0.10 sec)




mysql>  update lib set status="return" where bid=1;
   

Query OK, 1 row affected (0.06 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> select * from lib;
    -> //
+------+-------+------------+--------+
| bid  | bname | doi        | status |
+------+-------+------------+--------+
|    1 | cn    | 2018-08-08 | return |
+------+-------+------------+--------+
1 row in set (0.00 sec)




