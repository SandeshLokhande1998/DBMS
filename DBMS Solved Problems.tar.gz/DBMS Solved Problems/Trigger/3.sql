3: Write a database trigger on Library table. The System should keep track of the records that are being updated or deleted. The old value of updated or deleted records should be added in Library_Audit table. 

Library (bid, bname, doi, status)
Library_Audit table(bid,bname,noc,timestamp of query,FINE)




DELIMITER //

 trigger before_delete_lib
before delete
on lib
for each row
begin
insert into lib_audit values(old.bid,old.bname,old.doi,old.status);
end //

DELIMITER ;


select * from lib;
+------+-------+------------+--------+
| bid  | bname | doi        | status |
+------+-------+------------+--------+
|    1 | TOC   | 2018-10-01 | return |
|    2 | DBMS  | 2018-09-25 | return |
+------+-------+------------+--------+
2 rows in set (0.00 sec)

mysql> delete from lib where bid=2;
Query OK, 1 row affected (0.11 sec)




mysql> select * from lib;
+------+-------+------------+--------+
| bid  | bname | doi        | status |
+------+-------+------------+--------+
|    1 | TOC   | 2018-10-01 | return |
+------+-------+------------+--------+
1 row in set (0.00 sec)

mysql> select * from lib_audit;
+------+-------+------------+--------+
| bid  | bname | doi        | status |
+------+-------+------------+--------+
|    2 | DBMS  | 2018-09-25 | return |
+------+-------+------------+--------+
1 row in set (0.00 sec)





 delimiter //
 create trigger before_update_lib
     BEFORE UPDATE
     ON lib
     FOR EACH ROW
    begin
     insert into lib_audit values(old.bid,old.bname,old.doi,old.status);
     end //
Query OK, 0 rows affected (0.12 sec)

mysql> delimiter ;
mysql> select * from lib;
+------+-------+------------+--------+
| bid  | bname | doi        | status |
+------+-------+------------+--------+
|    1 | TOC   | 2018-10-01 | return |
+------+-------+------------+--------+
1 row in set (0.00 sec)


mysql> update lib set status="issue" where bid=1;
Query OK, 1 row affected (0.16 sec)
Rows matched: 1  Changed: 1  Warnings: 0


mysql> select * from lib_audit;
+------+-------+------------+--------+
| bid  | bname | doi        | status |
+------+-------+------------+--------+
|    2 | DBMS  | 2018-09-25 | return |
|    1 | TOC   | 2018-10-01 | return |
+------+-------+------------+--------+
2 rows in set (0.00 sec)

mysql> select * from lib;
+------+-------+------------+--------+
| bid  | bname | doi        | status |
+------+-------+------------+--------+
|    1 | TOC   | 2018-10-01 | issue  |
+------+-------+------------+--------+
1 row in set (0.00 sec)

