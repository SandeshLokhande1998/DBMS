25.Create the following tables.
9.
Deposit (actno,cname,bname,amount,adate)
10. Branch (bname,city)
11. Customers (cname, city)
12. Borrow(loanno,cname,bname, amount)
Add primary key and foreign key wherever applicable.
Insert data into the above created tables.
1.
Display loan no and loan amount of borrowers having the same branch as that of
sunil.
2.
Display deposit and loan details of customers in the city where pramod is living.
3.
Display borrower names having deposit amount greater than 1000 and having the
same living city as pramod.
4.
Display branch and living city of ‘ABC’



mysql> use d21;
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Database changed


mysql> insert into deposit values(13,'sunil','amalner',56565,'2018-07-09');
Query OK, 1 row affected (0.07 sec)

mysql> insert into borrow values(32,'sunil','amalner',9090);
Query OK, 1 row affected (0.05 sec)

mysql> insert into borrow values(32,'rutu','amalner',90090);
Query OK, 1 row affected (0.05 sec)

mysql> insert into borrow values(32,'rtr','amalner',90090);
Query OK, 1 row affected (0.06 sec)

mysql> update borrow set loanno=33 where cname='rutu';
Query OK, 1 row affected (0.07 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> update borrow set loanno=34 where cname='rtr';
Query OK, 1 row affected (0.08 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> select * from borrow;
+--------+--------+------------+--------+
| loanno | cname  | bname      | amount |
+--------+--------+------------+--------+
|     10 | nilesh | pimpri     |   4644 |
|     11 | abc    | samtanagar |  44644 |
|     32 | sunil  | amalner    |   9090 |
|     33 | rutu   | amalner    |  90090 |
|     34 | rtr    | amalner    |  90090 |
+--------+--------+------------+--------+
5 rows in set (0.00 sec)

mysql> select loanno,amount from borrow where bname=(select bname from deposit where cname='sunil');
+--------+--------+
| loanno | amount |
+--------+--------+
|     32 |   9090 |
|     33 |  90090 |
|     34 |  90090 |
+--------+--------+
3 rows in set (0.00 sec)



mysql> select deposit.accno,deposit.cname,borrow.loanno,borrow.amount from deposit inner join borrow on deposit.cname=borrow.cname where deposit.bname=(select city from customers where cname='pramod');
Empty set (0.00 sec)


mysql> update customers set city='amalner' where cname='pramod';
Query OK, 0 rows affected (0.00 sec)
Rows matched: 0  Changed: 0  Warnings: 0

mysql> select deposit.accno,deposit.cname,borrow.loanno,borrow.amount from deposit inner join borrow on deposit.cname=borrow.cname where deposit.bname=(select city from customers where cname='pramod');
Empty set (0.00 sec)

mysql> select deposit.accno,deposit.cname,borrow.loanno,borrow.amount from deposit left join borrow on deposit.cname=borrow.cname where deposit.bname=(select city from customers where cname='pramod')
    -> union
    -> select deposit.accno,deposit.cname,borrow.loanno,borrow.amount from deposit left join borrow on deposit.cname=borrow.cname where deposit.bname=(select city from customers where cname='pramod');
Empty set (0.00 sec)

mysql> insert into deposit values(45,'rtr','amalner',909,'2012-09-09');
Query OK, 1 row affected (0.07 sec)

mysql> insert into deposit values(46,'rtrtr','amalner',90976,'2012-09-09');
Query OK, 1 row affected (0.08 sec)

mysql> insert into deposit values(46,'kunal','amalner',90976,'2012-09-09');
Query OK, 1 row affected (0.06 sec)

mysql> select deposit.accno,deposit.cname,borrow.loanno,borrow.amount from deposit left join borrow on deposit.cname=borrow.cname where deposit.bname=(select city from customers where cname='pramod') union select deposit.accno,deposit.cname,borrow.loanno,borrow.amount from deposit left join borrow on deposit.cname=borrow.cname where deposit.bname=(select city from customers where cname='pramod');
Empty set (0.00 sec)





mysql> select borrow.cname from ((borrow inner join deposit on borrow.cname=deposit.cname)inner join customers on borrow .cname=customers.cname)where deposit.amount>1000 and borrow.bname=(select city from customers where cname='pramod');
Empty set (0.00 sec)

mysql> select * from borrow;
+--------+--------+------------+--------+
| loanno | cname  | bname      | amount |
+--------+--------+------------+--------+
|     10 | nilesh | pimpri     |   4644 |
|     11 | abc    | samtanagar |  44644 |
|     32 | sunil  | amalner    |   9090 |
|     33 | rutu   | amalner    |  90090 |
|     34 | rtr    | amalner    |  90090 |
+--------+--------+------------+--------+
5 rows in set (0.00 sec)

mysql> select * from deposit;
+-------+--------+---------+--------+------------+
| accno | cname  | bname   | amount | adate      |
+-------+--------+---------+--------+------------+
|     4 | abcd   | abc     | 4090   | 2018-09-08 |
|    46 | kunal  | amalner | 90976  | 2012-09-09 |
|     1 | nitesh | pimpri  | 4000   | 2014-07-08 |
|    10 | pk     | nagpur  | 4656   | 2018-07-07 |
|     2 | ritesh | malvan  | 40000  | 2014-07-08 |
|     3 | ritu   | malvan  | 409000 | 2014-09-08 |
|    45 | rtr    | amalner | 909    | 2012-09-09 |
|    46 | rtrtr  | amalner | 90976  | 2012-09-09 |
|    13 | sunil  | amalner | 56565  | 2018-07-09 |
+-------+--------+---------+--------+------------+
9 rows in set (0.00 sec)

mysql> select * from customers;
+---------+--------+
| cname   | city   |
+---------+--------+
| nitesh  | pune   |
| shreyas | malvan |
| abc     | nagpur |
| cdy     | bombay |
| tct     | nagpur |
| pk      | mumbai |
+---------+--------+
6 rows in set (0.00 sec)




mysql> select borrow.cname from ((borrow inner join deposit on borrow.cname=deposit.cname)inner join customers on borrow .cname=customers.cname)where deposit.amount>1000 and borrow.bname=(select city from customers where cname='pramod');
Empty set (0.00 sec)

mysql> select borrow.cname from ((borrow inner join deposit on borrow.cname=deposit.cname)inner join customers on borrow .cname=customers.cname)where deposit.amount>900 and borrow.bname=(select city from customers where cname='pramod');
Empty set (0.00 sec)

mysql> select customers.city,deposit.bname from customers inner join deposit on customers.cname=deposit.cname where customers.cname='abc';
Empty set (0.00 sec)

mysql> 
