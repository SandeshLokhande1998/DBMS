26.Create the following tables.
13. Deposit (actno,cname,bname,amount,adate)
14. Branch (bname,city)
15. Customers (cname, city)
16. Borrow(loanno,cname,bname, amount)
Add primary key and foreign key wherever applicable.Insert data into the above created
tables.
1.
Display amount for depositors living in the city where Anil is living.
2.
Display total loan and maximum loan taken from KAROLBAGH branch.
3.
Display total deposit of customers having account date later than ‘1-jan-98’.
4.
Display maximum deposit of customers living in PUNE.



mysql> use d21;
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Database changed
mysql> mysql> insert into customers 'anil','amalner');
Query OK, 1 row affected (0.07 sec)

mysql> select deposit.amount from deposit inner join customers on deposit.cname=customers.cname where deposit.bname=(select city from customers where cname='anil');
+--------+
| amount |
+--------+
| 909    |
| 90976  |
| 90976  |
+--------+
3 rows in set (0.00 sec)


mysql> select sum(amount),max(amount) from borrow where bname='amalner';
+-------------+-------------+
| sum(amount) | max(amount) |
+-------------+-------------+
|      189270 |       90090 |
+-------------+-------------+
1 row in set (0.00 sec)

mysql> select sum(amount) from deposit where adate>'1998-01-01';
+-------------+
| sum(amount) |
+-------------+
|      701172 |
+-------------+
1 row in set (0.00 sec)

mysql> select * from deposit;
+-------+--------+---------+--------+------------+
| accno | cname  | bname   | amount | adate      |
+-------+--------+---------+--------+------------+
|     4 | abcd   | abc     | 4090   | 2018-09-08 |
|    46 | kunal  | amalner | 90976  | 2012-09-09 |
|     1 | nitesh | pimpri  | 4000   | 2014-07-08 |
|    10 | pk     | nagpur  | 4656   | 2018-07-07 |
|     2 | ritesh | malvan  | 40000  | 2014-07-08 |
|     3 | ritu   | malvan  | 409000 | 2014-09-08 |
|    45 | rtr    | amalner | 909    | 2012-09-09 |
|    46 | rtrtr  | amalner | 90976  | 2012-09-09 |
|    13 | sunil  | amalner | 56565  | 2018-07-09 |
+-------+--------+---------+--------+------------+
9 rows in set (0.00 sec)

mysql> select max(amount) from deposit where cname=(select cname from customers where city='pune');
+-------------+
| max(amount) |
+-------------+
| 4000        |
+-------------+
1 row in set (0.00 sec)

mysql> 

